﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

public partial class frmFacultyRegistration : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        lblMsg.Text = "";
    }

    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        try
        {
            clsFaculty objFac = new clsFaculty();
            objFac.FName = txtFname.Text;
            objFac.MName = txtMName.Text;
            objFac.LName = txtLname.Text;
            objFac.DOB = txtDOB.Text;
            objFac.Address = txtAddress.Text;
            objFac.EmailId = txtEmailid.Text;
            objFac.PhoneNo = txtPhoneNo.Text;
            objFac.ImageFile = Convert.ToString(Session["FileName"]);
            objFac.ImageContent = (byte[])Session["Photo"];
            objFac.UserName = txtUserName.Text;
            objFac.Pwd = txtPassword.Text;
            objFac.Remarks = txtRemarks.Text;
            objFac.Experience = txtExperience.Text;
            string strMsg;
            int i = objFac.InsertFacultyDetails(out strMsg);
            if (strMsg != "0")
            {
                objFac.CourseId = Convert.ToInt32(DropDownList1.SelectedValue);
                objFac.FacultyId = Convert.ToInt32(strMsg);
                objFac.DescByFaculty = txtDescAbtCourse.Text;
                objFac.Description = txtAchdescription.Text;
                objFac.SpRemarks = txtspremarks.Text;
                objFac.InsertCourseandAchievementsByFaculty();
                lblMsg.Text = "Registration completed Sucessfully.";
                BrowseImage1.LoadDefaultImage();
                ClearData();

            }
            else
                lblMsg.Text = "UserName Alreadyy in use Choose another.";
            
        }
        catch (Exception ex)
        {
            lblMsg.Text = ex.Message;
        }
    }

    void ClearData()
    {
        try
        {
            txtspremarks.Text = "";
            txtAddress.Text = "";
            txtDOB.Text = "";
            txtEmailid.Text = "";
            txtFname.Text = "";
            txtLname.Text = "";
            txtMName.Text = "";
            txtPassword.Text = "";
            txtPhoneNo.Text = "";
            txtUserName.Text = "";
            txtRemarks.Text = "";
            txtExperience.Text = "";
            BrowseImage1.LoadDefaultImage();
            txtAchdescription.Text = "";
            txtRemarks.Text = "";
            txtDescAbtCourse.Text = "";
            if (DropDownList1.Items.Count != 0)
                DropDownList1.SelectedIndex = 0;
        }
        catch (Exception ex)
        {
            lblMsg.Text = ex.Message;
        }
    }

    protected void btnClearAll_Click(object sender, EventArgs e)
    {
        ClearData();
    }
  
    

    
    protected void DropDownList1_DataBound(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            DropDownList1.Items.Insert(0, "--Select One--");
        }
    }
}
