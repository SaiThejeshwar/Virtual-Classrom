﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

public partial class frmStudentRegistration : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        lblMsg.Text = "";
    }
    static int Studid;
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        try
        {
            clsStudents objStd = new clsStudents();
            objStd.FName = txtFname .Text;
            objStd.MName = txtMName .Text;
            objStd.LName = txtLname .Text;
            objStd.DOB = txtDOB .Text;
            objStd.Address = txtAddress.Text;
            objStd.EmailId = txtEmailid.Text;
            objStd.PhoneNo = txtPhoneNo.Text;
            objStd.ImageFile = Convert.ToString(Session["FileName"]);
            objStd.ImageContent = (byte[])Session["Photo"];
            objStd.UserName = txtUserName.Text;
            objStd.Pwd = txtPassword.Text;
            objStd.CourseId = Convert.ToInt32(ddlCourseId.SelectedValue);
            string strMsg;
       
            int i=objStd.InsertStudentDetails(out strMsg,out Studid);
            if (i > 1)
            {
                ClearData();
                lblMsg.Text = strMsg;
                BrowseImage1.LoadDefaultImage();
                btnSubmit.Enabled = false;
                btnFees.Enabled = true;
            }
            else
                lblMsg.Text = strMsg;
        }
        catch (Exception ex)
        {
            lblMsg.Text = ex.Message;
        }
    }

    void ClearData()
    {
        try
        {
            txtAddress.Text = "";
            txtDOB .Text = "";
            txtEmailid.Text = "";
            txtFname .Text = "";
            txtMName.Text = "";
            txtLname .Text = "";
            txtLname .Text = "";
            txtPassword.Text = "";
            txtPhoneNo.Text = "";
            txtUserName.Text = "";
            BrowseImage1.LoadDefaultImage();
            if (ddlCourseId.SelectedIndex != 0)
                ddlCourseId.SelectedIndex = 0;
        }
        catch (Exception ex)
        {
            lblMsg.Text = ex.Message;
        }
    }

    protected void btnClearAll_Click(object sender, EventArgs e)
    {
        ClearData();
    }

    protected void ddlCourseId_DataBound(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            ddlCourseId.Items.Insert(0, "--Select One--");
        }
    }
    protected void btnFees_Click(object sender, EventArgs e)
    {
        try
        {
            btnSubmit.Enabled = true;
            Response.Redirect("frmStudentCoursefees.aspx?id=" + Studid);

        }
        catch (Exception ex)
        {

            lblMsg.Text = ex.Message;
        }
    }
}
