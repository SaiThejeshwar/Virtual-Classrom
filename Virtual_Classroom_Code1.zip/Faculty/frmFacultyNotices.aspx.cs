﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

public partial class Faculty_frmFacultyNotices : System.Web.UI.Page
{

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
           
        }
    }

    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        try
        {
            clsFaculty objFac = new clsFaculty();
            objFac.NoticeText = txtCname.Text;
            objFac.FacultyId = Convert.ToInt32(Session["FacultyId"]);
            objFac.NoticeFileName = Convert.ToString(Session["FileName"]);
            objFac.NoticeFileContent = (byte[])Session["FileContent"];
            int i = objFac.InsertFacultyNotices();
            if (i > 0)
            {
                ClearData();
                lblMsg.Text = "Notice Details Submited.";
            }
            else
                lblMsg.Text = "Error In Process Try Again..";
        }
        catch (Exception ex)
        {
            lblMsg.Text = ex.Message;   
        }
    }

    protected void btnClearAll_Click(object sender, EventArgs e)
    {
        ClearData();
    }

    void ClearData()
    {
        try
        {
            lblMsg.Text = "";
            txtCname.Text = "";
            Session["FileName"] = "";
            Session["FileContent"] = (byte[])null;
        }
        catch (Exception ex)
        {
            lblMsg.Text = ex.Message;
        }
    }

}
