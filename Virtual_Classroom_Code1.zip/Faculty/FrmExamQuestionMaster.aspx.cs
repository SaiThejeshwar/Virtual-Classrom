﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

public partial class Faculty_FrmExamQuestionMaster : System.Web.UI.Page
{
    Cls_ExamQuestionsMaster objEqtestQuestionandAnswers = new Cls_ExamQuestionsMaster();
    static int i=0, j;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            
        }
    }
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        try
        {

            if (i < Convert.ToInt32(Session["Question"]))
            {
                objEqtestQuestionandAnswers.ExaminationId =Convert.ToInt32( Session["ExaminationId"]);
                objEqtestQuestionandAnswers.Questiontext = txtQuestiontext.Text;
                objEqtestQuestionandAnswers.Answer1 = txtAnswers1.Text;
                objEqtestQuestionandAnswers.Answers2 = txtAnswers2.Text;
                objEqtestQuestionandAnswers.Answers3 = txtAnswer3.Text;
                objEqtestQuestionandAnswers.Answer4 = txtAnswer4.Text;
                objEqtestQuestionandAnswers.CorrectAnswer = txtCollectAnswers.Text;
                objEqtestQuestionandAnswers.Marks = Convert.ToInt32(ddlNoMarks.Text);
                int k =  objEqtestQuestionandAnswers.InsertQuestionAndAnswers();
                if (k > 0)
                {
                   
                    Cleardata();
                    lblMsg.Text = "Exam Questions Submited";

                }
                else
                {
                    lblMsg.Text = "Error Process Try Again...";
                }

                Session["Question"] = Convert.ToInt32(Session["Question"]) - 1;
                if (i == Convert.ToInt32(Session["Question"]))
                {
                    Cleardata();
                    Response.Redirect("~/Faculty/FrmExaminationSchedule.aspx");
                }

            }
            else
            {
                Cleardata();
                lblMsg.Text = "";
            }

        }
        catch (Exception ex)
        {

            lblMsg.Text = ex.Message;
        }
    }
    protected void btnClearAll_Click(object sender, EventArgs e)
    {
        Cleardata();
    }
    public void Cleardata()
    {
        try
        {
            txtAnswers1.Text = "";
            txtAnswers2.Text = "";
            txtAnswer3.Text = "";
            txtAnswer4.Text = "";
            txtCollectAnswers.Text = "";
            txtQuestiontext.Text = "";
            if (ddlNoMarks.SelectedIndex != 0)
                ddlNoMarks.SelectedIndex = 0;
            lblMsg.Text = "";

        }
        catch (Exception ex)
        {

            lblMsg.Text = ex.Message;
        }
    }
}
