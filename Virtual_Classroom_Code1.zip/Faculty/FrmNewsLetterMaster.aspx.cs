﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

public partial class Faculty_FrmNewsLetterMaster : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
          
        }

    }
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        try
        {
            Cls_NewsLetterMaster objNewsletterMaster = new Cls_NewsLetterMaster();
            objNewsletterMaster.NewsLetterText = txtCname.Text;
            objNewsletterMaster.FaculityId = Convert.ToInt32(Session["FacultyId"]);
            objNewsletterMaster.LetterUploadfiletext = Convert.ToString(Session["FileName"]);
            objNewsletterMaster.LetterUploadfile = (byte[])Session["FileContent"];
            int i = objNewsletterMaster.InsertNewsLetterMaster();
            if (i > 0)
            {
                ClearData();
                lblMsg.Text = "News Letter  Details Submited.";
            }
            else
                lblMsg.Text = "Error In Process Try Again..";
        }
        catch (Exception ex)
        {
            lblMsg.Text = ex.Message;
        }
    }
    protected void btnClearAll_Click(object sender, EventArgs e)
    {
        ClearData();
    }
    void ClearData()
    {
        try
        {
            lblMsg.Text = "";
            txtCname.Text = "";
            Session["FileName"] = "";
            Session["FileContent"] = (byte[])null;
        }
        catch (Exception ex)
        {
            lblMsg.Text = ex.Message;
        }
    }
}
