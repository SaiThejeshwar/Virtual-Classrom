﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Web.Mail;

public partial class Faculty_frmStudentExamination : System.Web.UI.Page
{
    Cls_StudentExaminationMaster objstudentexaminationMaster = new Cls_StudentExaminationMaster();
    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            if (!IsPostBack)
            {
               
                ddlStudentName.Items.Insert(0, "--SelectOne--");
                ShowExaminationId();
                
            }
        }
        catch (Exception ex)
        {

            lblMsg.Text = ex.Message;
        }
    }
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        try
        {
            objstudentexaminationMaster.ExamAttendeddate = Convert.ToDateTime(txtExamateendeddate.Text);
            objstudentexaminationMaster.ExaminationId = Convert.ToInt32(ddlExminationid.SelectedValue);
            objstudentexaminationMaster.StudentId = Convert.ToInt32(ddlStudentName.SelectedValue);
            int i = objstudentexaminationMaster.InsertStudentExaminaion();
            if (i > 0)
            {
                SendMails(txtExamateendeddate.Text, i);
                Cleradata();
                lblMsg.Text = "Student Examination Details Submited.";
            }
            else
            {
                lblMsg.Text = "Error Process Try Again..";
            }

        }
        catch (Exception ex)
        {

            lblMsg.Text = ex.Message;
        }
    }
    protected void btnClearAll_Click(object sender, EventArgs e)
    {
        Cleradata();
    }
    protected void ddlExminationid_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            if (ddlExminationid.SelectedIndex != 0)
            {
                DataSet ds = Cls_StudentExaminationMaster.ShowStudentId(Convert.ToInt32(ddlExminationid.SelectedValue));
                if (ds.Tables[0].Rows.Count != 0)
                {
                    ddlStudentName.DataSource = ds.Tables[0];
                    ddlStudentName.DataTextField = "FName";
                    ddlStudentName.DataValueField = "StudentId";
                    ddlStudentName.DataBind();
                }
                ddlStudentName.Items.Insert(0, "--SelectOne--");
            }
            else
            {
                ddlStudentName.Items.Clear();
                ddlStudentName.Items.Insert(0, "--SelectOne--");
            }
        }
        catch (Exception ex)
        {

            lblMsg.Text = ex.Message;
        }
    }
    public void ShowExaminationId()
    {
        try
        {
            DataSet ds = Cls_StudentExaminationMaster.ShowExaminationID(Convert.ToInt32(Session["FacultyId"]));
            if (ds.Tables[0].Rows.Count != 0)
            {
                ddlExminationid.DataSource = ds.Tables[0];
                ddlExminationid.DataTextField = "ExaminationText";
                ddlExminationid.DataValueField = "ExaminationId";
                ddlExminationid.DataBind();
            }
            ddlExminationid.Items.Insert(0, "--SelectOne--");
        }
        catch (Exception ex)
        {

            lblMsg.Text = ex.Message;
        }
    }
    public void Cleradata()
    {
        txtExamateendeddate.Text = "";
        if (ddlExminationid.SelectedIndex != 0) ;
        ddlExminationid.SelectedIndex = 0;
        if (ddlStudentName.SelectedIndex != 0) ;
        ddlStudentName.SelectedIndex = 0;    
        lblMsg.Text = "";

    }
    void SendMails(string date,int StdExamId)
    {
        MailMessage objMail = new MailMessage();
        objMail.From = "virtualclassroom.Com";
        objMail.To = "Localhost";
        objMail.Subject = "Examinaton Schedule.";
        objMail.Body = "Your Examinaton Id   : " + StdExamId + "" + "\n" +
                       "Your Examination Date: " + date;
                       

        SmtpMail.SmtpServer = "LocalHost";
        SmtpMail.Send(objMail);
    
    }
}
