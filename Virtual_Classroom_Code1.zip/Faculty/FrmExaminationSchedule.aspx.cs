﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

public partial class Faculty_FrmExaminationSchedule : System.Web.UI.Page
{
    Cls_ExaminationSchedule objexaminationschedule = new Cls_ExaminationSchedule();
    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            if (!IsPostBack)
            {
               
                ShowCourseId();
            }
        }
        catch ( Exception ex)
        {

            lblMsg.Text = ex.Message;
        }
    }
    protected void ddlCourses_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            if (ddlCourses.SelectedIndex != 0)
            {
                DataSet ds = Cls_ExaminationSchedule.ShowLectureId(Convert.ToInt32(ddlCourses.SelectedValue));
                if (ds.Tables[0].Rows.Count != 0)
                {
                    ddllecturedescription.DataSource = ds.Tables[0];
                    ddllecturedescription.DataTextField = "lecdescription";
                    ddllecturedescription.DataValueField = "lectureid";
                    ddllecturedescription.DataBind();
                    ddllecturedescription.Items.Insert(0, "--SelectOne--");
                }
                
            }
            else
            {
                ddllecturedescription.Items.Clear();
                ddllecturedescription.Items.Insert(0, "--SelectOne--");

            }
        }
        catch (Exception ex)
        {

            lblMsg.Text = ex.Message;
        }
    }
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        try
        {
            objexaminationschedule.Examinationtext = txtDescription.Text;
            objexaminationschedule.CourseId = Convert.ToInt32(ddlCourses.SelectedValue);
            objexaminationschedule.LectureId = Convert.ToInt32(ddllecturedescription.SelectedValue);
            objexaminationschedule.FacultyId = Convert.ToInt32(Session["FacultyId"]);
            objexaminationschedule.PassPercentageDecided = ddlPasspercentage.Text;
            objexaminationschedule.NoOfQuestions = Convert.ToInt32(ddlNumberofquestion.Text);
            int i =  objexaminationschedule.InsertExaminationSchedule();
            Session["Question"] = ddlNumberofquestion.Text;
            Session["ExaminationId"] = i.ToString();
            if (i > 0)
            {
                
                Cleradata();

                lblMsg.Text = "Examination Details Submited.";
                Response.Redirect("~/Faculty/FrmExamQuestionMaster.aspx");
            }
            else
            {
                lblMsg.Text = "Error In Process Try Again..";
            }
        }
        catch (Exception ex)
        {

            lblMsg.Text = ex.Message;
        }
    }
    protected void btnClearAll_Click(object sender, EventArgs e)
    {
        Cleradata();
    }

    public void ShowCourseId()
    {
        try
        {
            DataSet ds = Cls_ExaminationSchedule.ShowCourseId(Convert.ToInt32(Session["FacultyId"]));
            if (ds.Tables[0].Rows.Count != 0)
            {
                ddlCourses.DataSource = ds.Tables[0];
                ddlCourses.DataTextField = "Coursename";
                ddlCourses.DataValueField = "CourseId";
                ddlCourses.DataBind();
            }
            ddlCourses.Items.Insert(0, "--SelectOne--");
        }
        catch (Exception ex)
        {

            lblMsg.Text = ex.Message;
        }
    }
    public void Cleradata()
    {
        txtDescription.Text = "";
    if (ddlPasspercentage.SelectedIndex != 0) 
    ddlPasspercentage.SelectedIndex = 0;
        if (ddlCourses.SelectedIndex != 0) 
        ddlCourses.SelectedIndex = 0;
        if (ddllecturedescription.SelectedIndex != 0)
            ddllecturedescription.SelectedIndex = 0;
        if (ddlNumberofquestion.SelectedIndex != 0)
            ddlNumberofquestion.SelectedIndex = 0;
        lblMsg.Text = "";

    }
}
