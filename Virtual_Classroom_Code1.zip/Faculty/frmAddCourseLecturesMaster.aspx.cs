﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

public partial class Faculty_frmAddCourseLecturesMaster : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            lblMsg.Text = "";
           
        }
    }

    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        try
        {
            clsCourses objCour = new clsCourses();
            objCour.FacultyId = Convert.ToInt32(Session["FacultyId"]);
            objCour.CourseId = Convert.ToInt32(ddlCourses.SelectedValue);
            objCour.LecDescription = txtDescription.Text;
            objCour.LecDurationTime = txtDuration.Text;
            if (Session["AudioFileName"] != null && Session["AudioFileContent"] != null)
            {
                objCour.LecAudioFileName = (string)Session["AudioFileName"];
                objCour.LecAudioFileContent = (byte[])Session["AudioFileContent"];
            }
            else
            {
                lblMsg.Text = "Audio File Not Attached.Try again.";
                return;
            }
            if (Session["VideoFileName"] != null && Session["VideoFileContent"] != null)
            {
                objCour.LecVideoFileName = (string)Session["VideoFileName"];
                objCour.LecVideoFileContent = (byte[])Session["VideoFileContent"];
            }
            else
            {
                lblMsg.Text = "Video File Not Attached.Try again.";
                return;
            }
            if (Session["PPTFileName"] != null && Session["PPTFileContent"] != null)
            {
                objCour.LecPowerPointFileName = (string)Session["PPTFileName"];
                objCour.LecPowerPointFileContent = (byte[])Session["PPTFileContent"];
            }
            else
            {
                lblMsg.Text = "PPT File Not Attached.Try again.";
                return;
            }
            if (Session["DocFileName"] != null && Session["DocFileContent"] != null)
            {
                objCour.LecDocFileName = (string)Session["DocFileName"];
                objCour.LecDocFileContent = (byte[])Session["DocFileContent"];
            }
            else
            {
                lblMsg.Text = "Document File Not Attached.Try again.";
                return;
            }
            if (Session["AssignFileName"] != null && Session["AssignFileContent"] != null)
            {
                objCour.LecAssignmentFileName = (string)Session["AssignFileName"];
                objCour.LecAssignmentFileContent = (byte[])Session["AssignFileContent"];
            }
            else
            {
                lblMsg.Text = "Document File Not Attached.Try again.";
                return;
            }
            int j = objCour.InsertCourselecturesMasterData();
            if (j == 1)
            {
                ClearData();
                lblMsg.Text = "Your Lecture Details Added";
            }
            else
                lblMsg.Text = "Process Not completed..Try again.";
        }
        catch (Exception ex)
        {
            lblMsg.Text = ex.Message;
        }
    }

    private void ClearData()
    {
        try
        {
            lblMsg.Text = "";
            txtDescription.Text = "";
            txtDuration.Text = "";
            Session["AudioFileName"] = null;
            Session["AudioFileContent"] = null;
            Session["VideoFileName"] = null;
            Session["VideoFileContent"] = null;
            Session["PPTFileName"] = null;
            Session["PPTFileContent"] = null;
            Session["DocFileName"] = null;
            Session["DocFileContent"] = null;
            Session["AssignFileName"] = null;
            Session["AssignFileContent"] = null;
            if (ddlCourses.Items.Count != 0)
                ddlCourses.SelectedIndex = 0;
        }
        catch (Exception ex)
        {
            lblMsg.Text = ex.Message;
        }
    }

    protected void btnClearAll_Click(object sender, EventArgs e)
    {
        ClearData();
    }

    protected void ddlCourses_DataBound(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            ddlCourses.Items.Insert(0, "--Select One--");
        }
    }
}
