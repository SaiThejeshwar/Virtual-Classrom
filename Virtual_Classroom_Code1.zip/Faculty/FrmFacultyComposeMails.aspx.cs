﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

public partial class Faculty_FrmFacultyComposeMails : System.Web.UI.Page
{
    Cls_EmailMaster objEmailmaster = new Cls_EmailMaster();
    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            if (!IsPostBack)
            {
                ddlto.Items.Insert(0, "--Select EmailId--");
            }
        }
        catch (Exception ex)
        {

            lblMsg.Text = ex.Message;
        }

    }
    protected void rdbAdmin_CheckedChanged(object sender, EventArgs e)
    {
        try
        {
            DataSet ds = Cls_EmailMaster.ShowAdminEmails();
            
            if (ds.Tables[0].Rows.Count != 0)
            {
                ddlto.DataSource = ds.Tables[0];
                ddlto.DataTextField = "Username";
                ddlto.DataValueField = "Std_Fac_Id";
                ddlto.DataBind();
            }
            else
            {
                ddlto.Items.Clear();

            }
            ddlto.Items.Insert(0, "--Select EmailId--");
            txtbody.Text = "";
            txtsubject.Text = "";
            lblMsg.Text = "";
        }
        catch (Exception ex)
        {

            lblMsg.Text = ex.Message;
        }
    }
    protected void rdbstudent_CheckedChanged(object sender, EventArgs e)
    {
        try
        {
            DataSet ds = Cls_EmailMaster.ShowStudentEmailsFacultyWise(Convert.ToInt32(Session["FacultyId"]));

            if (ds.Tables[0].Rows.Count != 0)
            {
                ddlto.DataSource = ds.Tables[0];
                ddlto.DataTextField = "Username";
                ddlto.DataValueField = "Std_Fac_Id";
                ddlto.DataBind();
            }
            else 
            {
                ddlto.Items.Clear();

            }
            ddlto.Items.Insert(0, "--Select EmailId--");
            txtbody.Text = "";
            txtsubject.Text = "";
            lblMsg.Text = "";
        }
        catch (Exception ex)
        {

            lblMsg.Text = ex.Message;
        }
    }
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        try
        {
            string str = "";
            System.Text.ASCIIEncoding encoding = new System.Text.ASCIIEncoding();
            byte[] data = encoding.GetBytes(str);

            objEmailmaster.EmailSenderId = Convert.ToInt32(Session["FacultyId"]);
            objEmailmaster.EMailBodyMsg = txtbody.Text;
            objEmailmaster.EmailSubjectText = txtsubject.Text;
            objEmailmaster.EmailReciptedId = Convert.ToInt32(ddlto.SelectedValue);

            if (Session["FileName"] != null && Session["FileContent"] != null )
            {
                objEmailmaster.EmailAttachFileName = Convert.ToString(Session["FileName"]);
                objEmailmaster.EmailAttachFileContent = (byte[])Session["FileContent"];
            }
            else
            {
                objEmailmaster.EmailAttachFileName = "No FIle";
                objEmailmaster.EmailAttachFileContent = data;
            }
            int i = objEmailmaster.InsertEmailMaster();
            if (i > 0)
            {
                ClearData();
                lblMsg.Text = "Your message has been sent..";
            }
            else
            {
                lblMsg.Text = "Message Failed..";
            }
        }
        catch (Exception ex)
        {

            lblMsg.Text = ex.Message;
        }
        
    }
    public void ClearData()
    {
        Session["FileName"] = null;
        Session["FileContent"] = null;
        txtsubject.Text = "";
        txtbody.Text = "";
        if (ddlto.SelectedIndex != 0)
            ddlto.SelectedIndex = 0;
        lblMsg.Text = "";
    }
}
