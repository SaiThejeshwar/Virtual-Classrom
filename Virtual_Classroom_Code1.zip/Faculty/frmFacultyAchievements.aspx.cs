﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

public partial class Faculty_frmFacultyAchievements : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        
    }
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        try
        {
            clsFaculty objFac = new clsFaculty();
            objFac.CourseId = Convert.ToInt32(DropDownList1.SelectedValue);
            objFac.FacultyId = Convert.ToInt32(Session["FacultyId"]);
            objFac.DescByFaculty = txtDescAbtCourse.Text;
            objFac.Description = txtAchdescription.Text;
            objFac.SpRemarks = txtRemarks.Text;
            int i = objFac.InsertCourseandAchievementsByFaculty();
            if (i > 0)
            {
                lblMsg.Text = "Your Course Experience and Achievements Details Added.";
                ClearData();
            }
            else
            {
                lblMsg.Text = "Error in Process. Try Again..";
            }
        }
        catch (Exception ex)
        {
            lblMsg.Text = ex.Message;
        }
    }
    protected void btnClearAll_Click(object sender, EventArgs e)
    {
        ClearData();
        lblMsg.Text = "";
    }

    void ClearData()
    {
        try 
        {
            
            txtAchdescription.Text = "";
            txtRemarks.Text = "";
            txtDescAbtCourse.Text = "";
            if (DropDownList1.Items.Count != 0)
                DropDownList1.SelectedIndex = 0;
        }
        catch (Exception ex)
        {
            lblMsg.Text = ex.Message;
        }
    }
    protected void DropDownList1_DataBound(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            DropDownList1.Items.Insert(0, "--Select One--");
        }
    }
}
