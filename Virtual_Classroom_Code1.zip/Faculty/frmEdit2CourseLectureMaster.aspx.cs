﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

public partial class Faculty_frmEdit2CourseLectureMaster : System.Web.UI.Page
{
    
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            BindData();
        }
    }

    private void BindData()
    {
        try
        {
            int Id = Convert.ToInt32(Request["LecId"]);
            DataSet ds = clsFaculty.GetFacultyLectureDataByLecId(Id);
            if (ds.Tables[0].Rows.Count != 0)
            {
                txtDescription.Text = ds.Tables[0].Rows[0][4].ToString();
                txtDuration.Text = ds.Tables[0].Rows[0][15].ToString();
                Session["AudioFileName"] = ds.Tables[0].Rows[0][5].ToString();
                Session["AudioFileContent"] = (byte[])ds.Tables[0].Rows[0][6];
                Session["VideoFileName"] = ds.Tables[0].Rows[0][7].ToString();
                Session["VideoFileContent"] = (byte[])ds.Tables[0].Rows[0][8];
                Session["PPTFileName"] = ds.Tables[0].Rows[0][9].ToString();
                Session["PPTFileContent"] = (byte[])ds.Tables[0].Rows[0][10];
                Session["DocFileName"] = ds.Tables[0].Rows[0][11].ToString();
                Session["DocFileContent"] = (byte[])ds.Tables[0].Rows[0][12];
                Session["AssignFileName"] = ds.Tables[0].Rows[0][13].ToString();
                Session["AssignFileContent"] = (byte[])ds.Tables[0].Rows[0][14];
            }
            else
                lblMsg.Text = "No data found for this record";
        }
        catch (Exception ex)
        {
            lblMsg.Text = ex.Message;
        }
    }

    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        try
        {
            clsCourses objCour = new clsCourses();
            objCour.LectureId = Convert.ToInt32(Request["LecId"]);
            objCour.LecDescription = txtDescription.Text;
            objCour.LecDurationTime = txtDuration.Text;
            if (Session["AudioFileName"] != null && Session["AudioFileContent"] != null)
            {
                objCour.LecAudioFileName = (string)Session["AudioFileName"];
                objCour.LecAudioFileContent = (byte[])Session["AudioFileContent"];
            }
            else
            {
                lblMsg.Text = "Audio File Not Attached.Try again.";
                return;
            }
            if (Session["VideoFileName"] != null && Session["VideoFileContent"] != null)
            {
                objCour.LecVideoFileName = (string)Session["VideoFileName"];
                objCour.LecVideoFileContent = (byte[])Session["VideoFileContent"];
            }
            else
            {
                lblMsg.Text = "Video File Not Attached.Try again.";
                return;
            }
            if (Session["PPTFileName"] != null && Session["PPTFileContent"] != null)
            {
                objCour.LecPowerPointFileName = (string)Session["PPTFileName"];
                objCour.LecPowerPointFileContent = (byte[])Session["PPTFileContent"];
            }
            else
            {
                lblMsg.Text = "PPT File Not Attached.Try again.";
                return;
            }
            if (Session["DocFileName"] != null && Session["DocFileContent"] != null)
            {
                objCour.LecDocFileName = (string)Session["DocFileName"];
                objCour.LecDocFileContent = (byte[])Session["DocFileContent"];
            }
            else
            {
                lblMsg.Text = "Document File Not Attached.Try again.";
                return;
            }
            if (Session["AssignFileName"] != null && Session["AssignFileContent"] != null)
            {
                objCour.LecAssignmentFileName = (string)Session["AssignFileName"];
                objCour.LecAssignmentFileContent = (byte[])Session["AssignFileContent"];
            }
            else
            {
                lblMsg.Text = "Document File Not Attached.Try again.";
                return;
            }
            int j = objCour.UpdateCourselecturesMasterData();
            if (j == 1)
            {
                ClearData();
                lblMsg.Text = "Your Lecture Details Modified.";
            }
            else
                lblMsg.Text = "Process not yet completed..Try again.";
        }
        catch (Exception ex)
        {
            lblMsg.Text = ex.Message;
        }
    }

    protected void btnClearAll_Click(object sender, EventArgs e)
    {
        ClearData();
    }

    private void ClearData()
    {
        try
        {
            lblMsg.Text = "";
            txtDescription.Text = "";
            txtDuration.Text = "";
            Session["AudioFileName"] = null;
            Session["AudioFileContent"] = null;
            Session["VideoFileName"] = null;
            Session["VideoFileContent"] = null;
            Session["PPTFileName"] = null;
            Session["PPTFileContent"] = null;
            Session["DocFileName"] = null;
            Session["DocFileContent"] = null;
            Session["AssignFileName"] = null;
            Session["AssignFileContent"] = null;
        }
        catch (Exception ex)
        {
            lblMsg.Text = ex.Message;
        }
    }
    protected void btnBack_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/Faculty/frmEdit1CourseLectureMaster.aspx");
    }
}
