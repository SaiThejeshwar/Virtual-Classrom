﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

public partial class Faculty_frmAssignmentRemarks : System.Web.UI.Page
{
    Cls_AssignmentRemarks objAssignmentRemarks = new Cls_AssignmentRemarks();
    static int id;
    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            if (!IsPostBack)
            {

                gridFaculty.DataSource = Cls_StudentAssignmentSubmissionmaster.ShowFacultyWiseStudentsDispalyew(Convert.ToInt32(Session["FacultyId"]));
                gridFaculty.DataBind();
            }
        }
        catch (Exception ex)
        {

            lblMsg.Text = ex.Message;
        }
    }
    protected void gridFaculty_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        try
        {
            id = Convert.ToInt32(e.CommandArgument);
            lblMsg.Text = "";
            if (e.CommandName == "m1")
            {
                DataSet ds = Cls_StudentAssignmentSubmissionmaster.ShowAssignmetDetailsDownload(id);
                if (ds.Tables[0].Rows.Count != 0)
                {
                    try
                    {
                        byte[] FileContent = (byte[])ds.Tables[0].Rows[0][5];
                        string FileName = (string)ds.Tables[0].Rows[0][6];
                        string[] fileSplit = FileName.Split('.');
                        int Loc = fileSplit.Length;
                        string FileExtention = "." + fileSplit[Loc - 1].ToUpper();

                        int i = 0;
                        if (FileExtention == ".DOC" || FileExtention == ".DOCX")
                        {
                            Response.ContentType = "application/vnd.ms-word";
                            Response.AddHeader("content-disposition", "inline;filename=" + FileName);
                            i = 1;
                        }
                        else if (FileExtention == ".XL" || FileExtention == ".XLS" || FileExtention == ".XLSX")
                        {
                            Response.ContentType = "application/vnd.ms-excel";
                            Response.AddHeader("content-disposition", "inline;filename=" + FileName);
                            i = 1;
                        }
                        else if (FileExtention == ".PDF")
                        {
                            Response.ContentType = "application/pdf";
                            Response.AddHeader("content-disposition", "inline;filename=" + FileName);
                            i = 1;
                        }
                        else if (FileExtention == ".TXT")
                        {
                            Response.ContentType = "application/octet-stream";
                            Response.AddHeader("content-disposition", "inline;filename=" + FileName);
                            i = 1;
                        }
                        if (i == 1)
                        {
                            Response.Charset = "";
                            Response.Cache.SetCacheability(HttpCacheability.NoCache);
                            Response.BinaryWrite(FileContent);
                            Response.End();
                        }
                        else
                            lblMsg.Text = "Problom in downloading the file..";
                    }

                    catch (Exception ex)
                    {
                        lblMsg.Text = "Problom in downloading the file.." + ex.Message;
                    }
                }

            }
            else if (e.CommandName == "s1")
            {
                
                DataSet ds=Cls_StudentAssignmentSubmissionmaster.ShowRemarksModifieddata(id);
                if (ds.Tables[0].Rows.Count != 0)
                {
                    lblMsg.Text = "Already Remarks Assigned..";
                }
                else
                {
                    panel1.Visible = true;
                }
            }

        }
        catch (Exception ex)
        {

            lblMsg.Text = ex.Message;
        }
    }
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        try
        {
            objAssignmentRemarks.AssignmentID = id;
            objAssignmentRemarks.FacultyId = Convert.ToInt32(Session["FacultyId"]);
            objAssignmentRemarks.RemarkstoStudent = txtremarks.Text;
            int i = objAssignmentRemarks.InsertAssignmentRemarks();
            if (i > 0)
            {
                lblMsg.Text = "Student  Remarks Assigned...";
                panel1.Visible = false;
                txtremarks.Text = "";
            }
            else
            {
                lblMsg.Text = "Error Process Try Again...";
            }
        }
        catch (Exception ex)
        {

            lblMsg.Text = ex.Message;
        }
    }
    protected void btnClearAll_Click(object sender, EventArgs e)
    {
        panel1.Visible = false;
        txtremarks.Text = "";
        lblMsg.Text = "";
    }
}
