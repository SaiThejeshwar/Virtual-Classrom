﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

public partial class frmStudentCoursefees : System.Web.UI.Page
{
    clsStudents objstudent = new clsStudents();
    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            if (!IsPostBack)
            {

                DataSet ds = clsCourses.ShowFeesDetailsCourseWise(Convert.ToInt32(Request["id"]));
                if (ds.Tables[0].Rows.Count != 0)
                {
                    ddlCourseId.DataSource = ds.Tables[0];
                    ddlCourseId.DataBind();
                    ddlStudenName.DataSource = ds.Tables[0];
                    ddlStudenName.DataBind();
                    txtPayAmount.Text = ds.Tables[0].Rows[0][2].ToString();

                }
            }
        }
        catch (Exception ex)
        {

            lblMsg.Text = ex.Message;
        }
    }
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        try
        {
            objstudent.StudentId =Convert.ToInt32(ddlStudenName.Text);
            objstudent.CourseId = Convert.ToInt32(ddlCourseId.Text);
            objstudent.PaymentType = ddlPaymentName.Text;
            if (txtCreditCardNo.Text == "")
                objstudent.Paymentno  = "";
            else
                objstudent.Paymentno = txtCreditCardNo.Text;
            if (txtPayAmount.Text == "")
                objstudent.Payamount = Convert.ToDecimal(0);
            else
            {
                objstudent.Payamount = Convert.ToDecimal(txtPayAmount.Text);
            }
            int i = objstudent.InserCoursefeesdetails();
            if (i > 0)
            {
                ClearData();
                lblMsg.Text = "Course Fees Paid.";
            }
            else
            {
                lblMsg.Text = "Error Process Try Again..";
            }

        }
        catch (Exception ex)
        {

            lblMsg.Text = ex.Message;
        }
    }
    protected void btnClearAll_Click(object sender, EventArgs e)
    {
        ClearData();
    }
    protected void ddlPaymentName_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (ddlPaymentName.SelectedIndex == 1)
        {
            lblCreditCard.Visible = false;
            txtCreditCardNo.Text = "";
           
           
            txtCreditCardNo.Visible = false;
            lblstudentamount.Visible = true;
            StudentPayAMount.Text = "";
           StudentPayAMount.Visible = true;
           RequiredFieldValidator3.Enabled = false;
           RequiredFieldValidator5.Enabled = true ;
        }
        if (ddlPaymentName.SelectedIndex == 2)
        {
            lblstudentamount.Visible = false;
            StudentPayAMount.Text = "";
            StudentPayAMount.Visible = false;
            lblCreditCard.Visible = true;
            lblCreditCard.Text = "Credit CardNo";
            txtCreditCardNo.Text = "";
            txtCreditCardNo.Visible = true;
            RequiredFieldValidator5.Enabled = false;
            RequiredFieldValidator3.Enabled = true ;

        }
        if (ddlPaymentName.SelectedIndex == 3)
        {
            lblCreditCard.Text  = "Check No";
            StudentPayAMount.Text = "";
            StudentPayAMount.Visible = false;
        }
    }
    public void ClearData()
    {
        txtCreditCardNo.Text = "";
        txtPayAmount.Text = "";
        ddlCourseId.Items.Clear();
        ddlStudenName.Items.Clear();
        ddlPaymentName.Items.Clear();
        StudentPayAMount.Text = "";
        lblMsg.Text = "";
    }
}
