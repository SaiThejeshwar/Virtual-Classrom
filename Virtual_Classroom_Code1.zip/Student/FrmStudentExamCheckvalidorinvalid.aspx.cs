﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

public partial class Student_FrmStudentExamCheckvalidorinvalid : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            if (!IsPostBack)
            {
                DataSet ds = Cls_StudentExaminationDetails.ShowStudentExaminationMaster(Convert.ToInt32(Request["id"]));
                if (ds.Tables[0].Rows.Count != 0)
                {
                    txtdate.Text = ds.Tables[0].Rows[0][1].ToString();
                    txtExamId.Text = ds.Tables[0].Rows[0][2].ToString();
                    ViewState["status"] = ds.Tables[0].Rows[0][6];
                }
            }
        }
        catch (Exception ex)
        {

            lblMsg.Text = ex.Message;
        }
    }
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        try
        {
            if (txtdate.Text == DateTime.Now.Date.ToString())
            {
                if (Convert.ToBoolean(ViewState["status"]) == false)
                {
                    Response.Redirect("~/Student/FrmStudentExaminationPaper.aspx?id=" + Convert.ToInt32(Request["id"]));
                }
                else
                {
                lblMsg.Text="Already Exam is Attend ..So Attend Another Exam.. ";
                }
            }
            else {
                lblMsg.Text = "Sorry Today Not Available in this  Exam ...";
            
            }
        }
        catch (Exception ex)
        {

            lblMsg.Text = ex.Message;
        }
    }
}
