﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

public partial class Student_FrmExamDetailsFacultyWise : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            if (!IsPostBack)
            {
                GetData();
            }
        }
        catch (Exception ex)
        {

            lblMsg.Text = ex.Message;
        }
    }
    protected void GridCourse_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        try
        {
            Response.Redirect("~/Student/FrmStudentExamCheckvalidorinvalid.aspx?id=" + e.CommandArgument);
            // Label l1 = (Label)GridCourse.Rows[e.ro].FindControl("l1").ToString();
        }
        catch (Exception ex)
        {

            lblMsg.Text = ex.Message;
        }
    }
    protected void GridCourse_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        try
        {
            GridCourse.PageIndex = e.NewPageIndex;
            GetData();
        }
        catch (Exception ex)
        {

            lblMsg.Text = ex.Message;
        }
    }
    public void GetData()
    {
        try
        {
            GridCourse.DataSource = Cls_StudentExaminationDetails.showExamDetailsStudentWise(Convert.ToInt32(Request["id"]), Convert.ToInt32(Session["StudentId"]));
            GridCourse.DataBind();
        }
        catch (Exception ex)
        {

            lblMsg.Text = ex.Message;
        }
    }
}
