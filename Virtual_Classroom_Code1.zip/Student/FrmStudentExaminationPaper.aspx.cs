﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

public partial class Student_FrmStudentExaminationPaper : System.Web.UI.Page
{
    static string text;
    static int id,marks;
    Cls_StudentExaminationDetails objexamdetails = new Cls_StudentExaminationDetails();
    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            if (!IsPostBack)
            {
                id = Convert.ToInt32(Request["id"]);
                GridView1.DataSource = Cls_StudentExaminationDetails.ShowExaminationAllDetails(id);
                GridView1.DataBind();
                Cls_ExamQuestionsMaster.Updatestatus(id,true);
            }
        }
        catch (Exception ex)
        {

            lblMsg.Text = ex.Message;
        }
    }
    RadioButton r1, r2, r3, r4;
    Label lblCorrectAnswer, lblNoMarks, lblQuestionID;
    public void Submit_Click(object sender, EventArgs e)
    {
        try
        {
            foreach (GridViewRow item in GridView1.Rows)
            {
                text = "Noanswers";
                lblCorrectAnswer = (Label)item.FindControl("lblcorrectAnswer");
                lblNoMarks = (Label)item.FindControl("lblNoofmarks");
                lblQuestionID = (Label)item.FindControl("lblQuestionId");
                r1 = (RadioButton)item.FindControl("RadioButton1");
                r2 = (RadioButton)item.FindControl("RadioButton2");
                r3 = (RadioButton)item.FindControl("RadioButton3");
                r4 = (RadioButton)item.FindControl("RadioButton4");

                if (r1.Checked || r2.Checked || r3.Checked || r4.Checked)
                {
                    if (r1.Checked)
                    {
                        text = r1.Text;
                    }
                    if (r2.Checked)
                    {
                        text = r2.Text;
                    }
                    if (r3.Checked)
                    {
                        text = r3.Text;
                    }
                    if (r4.Checked)
                    {
                        text = r4.Text;
                    }
                    if (lblCorrectAnswer.Text == text)
                    {
                        objexamdetails.InsertStudentExaminationDetails(id, lblQuestionID.Text, text, true);
                        marks += Convert.ToInt32(lblNoMarks.Text);
                    }
                    else
                    {
                        objexamdetails.InsertStudentExaminationDetails(id, lblQuestionID.Text, text, false);
                    }

                }
                else
                {
                    objexamdetails.InsertStudentExaminationDetails(id, lblQuestionID.Text, text, false);
                }
                Cls_StudentExaminationMaster.UpdatestudentMarks(id, marks);
            }
            Cls_StudentExaminationMaster.ShowExamresults(Convert.ToInt32(Session["StudentId"]));
            Response.Redirect("~/Student/FrmStudentExamSucesspaper.aspx");
        }
        catch (Exception ex)
        {
            lblMsg.Text = ex.Message;
        }
        finally
        {
            Response.Redirect("~/Student/FrmStudentExamSucesspaper.aspx");
        }


    }
}
