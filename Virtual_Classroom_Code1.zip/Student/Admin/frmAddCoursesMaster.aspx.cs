﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

public partial class Admin_frmCoursesMaster : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        lblMsg.Text = "";
        if (!IsPostBack)
        { 
        
        }
    }
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        try
        {
            string str = "";
            System.Text.ASCIIEncoding encoding = new System.Text.ASCIIEncoding();
            byte[] data = encoding.GetBytes(str);

            clsCourses objCour = new clsCourses();
            objCour.CourseName = txtCname.Text;
            objCour.Description = txtdescription.Text;
            objCour.Duration = txtDuration.Text;
            objCour.NoOfLectures = Convert.ToInt32(txtNoOfLectures.Text);
            objCour.CourseFees = Convert.ToDecimal(txtFees.Text);
            if (Session["FileName"] != null && Session["FileContent"] !=null)
            {
                objCour.CourseFileName = Convert.ToString(Session["FileName"]);
                objCour.CourseFileContent = (byte[])Session["FileContent"];
            }
            else
            {
                objCour.CourseFileName = "No FIle";
                objCour.CourseFileContent = data;
            }
            int i = objCour.InsertCourseDetails();
            if (i == 1)
            {
                lblMsg.Text = "Course Details Inserted.";
                ClearData();
            }
            else
                lblMsg.Text = "Error in inserting Data.";
        }
        catch (Exception ex)
        {
            lblMsg.Text = ex.Message;
        }
    }

    void ClearData()
    {
        try
        {
            txtCname.Text = "";
            txtdescription.Text = "";
            txtDuration.Text = "";
            txtNoOfLectures.Text = "";
            Session["FileName"] = "";
            Session["FileContent"] = "";
        }
        catch (Exception ex)
        {
            lblMsg.Text = ex.Message;   
        }
    }
    protected void btnClearAll_Click(object sender, EventArgs e)
    {
        ClearData();
    }
}
