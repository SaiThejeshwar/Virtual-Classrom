﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using CrystalDecisions.CrystalReports.Engine;

public partial class Admin_Reports_frmStudentReports : System.Web.UI.Page
{
    Cls_Common objcommon = new Cls_Common();
    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            ReportDocument objdocument = new ReportDocument();
            DataSet ds = objcommon.ShowStudentReport();
            objdocument.Load(Server.MapPath("~/Admin/Reports/CrystalReport.rpt"));
            objdocument.SetDataSource(ds.Tables[0]);
            CrystalReportViewer1.ReportSource = objdocument;
        }
        catch (Exception ex)
        {

            lblError.Text = ex.Message;
        }
    }
}
