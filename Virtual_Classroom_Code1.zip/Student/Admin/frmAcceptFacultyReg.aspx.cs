﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

public partial class Admin_frmAcceptFacultyReg : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        { 
        
        }
    }
    protected void GridView1_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        try
        {
            clsFaculty objFac = new clsFaculty();
            string CmdName=e.CommandName.ToString ();
            if (CmdName == "Courses")
            {
                int FacId = Convert.ToInt32(e.CommandArgument);
                DataSet ds = objFac.GetCoursesByFacultyId(FacId);
                if (ds.Tables[0].Rows.Count != 0)
                {
                    GridView2.DataSource = ds.Tables[0];
                    GridView2.DataBind();
                }
                else
                {
                    GridView2.EmptyDataText = "No Data Found..";
                    GridView2.DataBind();
                }
            }
            else if (CmdName == "Achievements")
            {
                int FacId = Convert.ToInt32(e.CommandArgument);
                DataSet ds = objFac.GetAchievementsByFacultyId(FacId);
                if (ds.Tables[0].Rows.Count != 0)
                {
                    GridView2.DataSource = ds.Tables[0];
                    GridView2.DataBind();
                }
                else
                {
                    GridView2.EmptyDataText = "No Data Found..";
                    GridView2.DataBind();
                }
            }
            else if (CmdName == "Accept")
            {
                int FacId = Convert.ToInt32(e.CommandArgument);
                int i = objFac.AcceptFacultyRegistration(FacId);
                if (i > 0)
                {
                    Page.RegisterClientScriptBlock("", "<script>alert('Faculty Registration Accepted..')</script>");
                    Response.Redirect("~/Admin/frmAcceptFacultyReg.aspx");
                    lblMsg.Text = "Faculty Registration Accepted..";
                }
                else
                    lblMsg.Text = "Error in process. try again.";
            }
        }
        catch (Exception ex)
        {
            lblMsg.Text = ex.Message;   
        }
    }
}
