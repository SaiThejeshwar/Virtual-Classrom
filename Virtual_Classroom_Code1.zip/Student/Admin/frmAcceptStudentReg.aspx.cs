﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

public partial class Admin_frmAcceptStudentReg : System.Web.UI.Page
{

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        { 
        
        }
    }

    protected void GridView1_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        try
        {
            lblMsg.Text = "";
            if (e.CommandName.ToString() == "Course")
            {
                int cmdArgId = Convert.ToInt32(e.CommandArgument);
                if (cmdArgId != 0)
                {
                    ViewState["CourseId"] = null;
                    clsCourses objCourse=new clsCourses();
                    DataSet ds = objCourse.GetCoursesDetailsByCourseId(cmdArgId);
                    if (ds.Tables[0].Rows.Count != 0)
                    {
                        DetailsView1.DataSource = ds.Tables[0];
                        DetailsView1.DataBind();
                        ViewState["CourseId"] = cmdArgId;
                    }
                    else
                    {
                        DetailsView1.EmptyDataText = "Course Not Selected.";
                        DetailsView1.DataBind();
                    }
                }
            }
            else if (e.CommandName.ToString() == "Fees")
            {
               
                    int cmdArgId = Convert.ToInt32(e.CommandArgument);
                    if (cmdArgId != 0)
                    {
                        DataSet ds = clsCourses.ShowStudentpayfeesdetails(cmdArgId);
                        if (ds.Tables[0].Rows.Count != 0)
                        {
                            DetailsView2.DataSource = ds.Tables[0];
                            DetailsView2.DataBind();
                            //ViewState["CourseId"] = cmdArgId;
                        }
                        else
                        {
                            DetailsView2.EmptyDataText = "Fees Not Payed.. Not Accepted Student";
                            DetailsView2.DataBind();
                        }
                    }
                
           }

            else if (e.CommandName.ToString() == "Accept")
            {
                if (ViewState["CourseId"] != null)
                {
                    int cmdArgId = Convert.ToInt32(e.CommandArgument);
                    if (cmdArgId != 0)
                    {
                        ViewState["StdId"] = Convert.ToInt32(e.CommandArgument);
                        pnlRegisterCourse.Visible = true;
                        BindFacultyData();
                    }
                }
                else
                    lblMsg.Text = "First View The Course Details Then Give Acceptence.. ";
            }
        }
        catch (Exception ex)
        {
            lblMsg.Text = ex.Message;
        }
    }

    private void BindFacultyData()
    {
        try
        {
            DataSet ds =clsFaculty.GetFacultyDataByCourseId(Convert.ToInt32(ViewState["CourseId"]));
            ddlFacultyId.DataSource = ds.Tables[0];
            ddlFacultyId.DataTextField = "Faculty Name";
            ddlFacultyId.DataValueField = "FacultyId";
            ddlFacultyId.DataBind();
            ddlFacultyId.Items.Insert(0, "--Select One--");
        }
        catch (Exception ex)
        {
            lblMsg.Text = ex.Message;     
        }
    }

    protected void btnRegister_Click(object sender, EventArgs e)
    {
        try 
        {
            clsStudents objStd = new clsStudents();
            objStd.StudentId = Convert.ToInt32(ViewState["StdId"]);
            objStd.FacultyId = Convert.ToInt32(ddlFacultyId.SelectedValue);
            objStd.CourseStartDate  = Convert.ToDateTime(txtStartDate.Text);
            objStd.CourseEndDate = Convert.ToDateTime(txtEndDate.Text);
            int i = objStd.InsertStudentCourseMaster();
            if (i == 1)
            {
                int j = objStd.AcceptStudentRegistration(Convert.ToInt32(ViewState["StdId"]));
                ClearData();
                lblMsg.Text = "Student Request Accepted For this Course.";
            }
        }
        catch (Exception ex)
        {
            lblMsg.Text = ex.Message;
        }
    }

    private void ClearData()
    {
        txtEndDate.Text = "";
        txtStartDate.Text = "";
        ViewState["CourseId"] = null;
        if (ddlFacultyId.SelectedIndex != 0)
            ddlFacultyId.SelectedIndex = 0;
    }

    protected void btnClose_Click(object sender, EventArgs e)
    {
        pnlRegisterCourse.Visible = false;
        Response.Redirect("~/Admin/frmAcceptStudentReg.aspx");

    }

}
