﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

public partial class Admin_frmUpdateCourseDetails : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {

        }
    }
   
    protected void DropDownList1_DataBound(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            DropDownList1.Items.Insert(0, "--Select One--");
        }
    }
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        try
        {
            clsCourses objCour = new clsCourses();
            objCour.CourseId = Convert.ToInt32(DropDownList1.SelectedValue);
            objCour.CourseName = txtCname.Text;
            objCour.Description = txtdescription.Text;
            objCour.Duration = txtDuration.Text;
            objCour.NoOfLectures = Convert.ToInt32(txtNoOfLectures.Text);
            if (Session["FileName"] != null && Session["FileContent"] != null)
            {
                objCour.CourseFileName = Convert.ToString(Session["FileName"]);
                objCour.CourseFileContent = (byte[])Session["FileContent"];
            }
            else
            {
                objCour.CourseFileName = "No FIle";
                objCour.CourseFileContent = (byte[])null;
            }
            int i = objCour.UpdateCourseDetails();
            if (i == 1)
            {
                lblMsg.Text = "Course Details Modified.";
                ClearData();
            }
            else
                lblMsg.Text = "Error in Process.";
        }
        catch (Exception ex)
        {
            lblMsg.Text = ex.Message;
        }
    }
    protected void btnClearAll_Click(object sender, EventArgs e)
    {
        ClearData();
    }

    void ClearData()
    {
        if (DropDownList1.Items.Count != 0)
            DropDownList1.SelectedIndex = 0;
        txtCname.Text = "";
        txtdescription.Text = "";
        txtDuration.Text = "";
        txtNoOfLectures.Text = "";
        lblFileName.Text = "";
    }


    protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
    {
        clsCourses objCours = new clsCourses();
        try
        {

            if (DropDownList1.SelectedIndex != 0)
            {
                int CourseId = Convert.ToInt32(DropDownList1.SelectedValue);
                DataSet dsCourseData = objCours.GetCoursesDetailsByCourseId(CourseId);
                if (dsCourseData.Tables[0].Rows.Count != 0)
                {
                    txtCname.Text = dsCourseData.Tables[0].Rows[0][1].ToString();
                    txtdescription.Text = dsCourseData.Tables[0].Rows[0][2].ToString();
                    txtDuration.Text = dsCourseData.Tables[0].Rows[0][3].ToString();
                    txtNoOfLectures.Text = dsCourseData.Tables[0].Rows[0][6].ToString();
                    lblFileName.Text = dsCourseData.Tables[0].Rows[0][4].ToString();
                    
                    Session["FileName"] = dsCourseData.Tables[0].Rows[0][4].ToString();
                    Session["FileContent"] = (byte[])dsCourseData.Tables[0].Rows[0][5];
                }
            }
            else
                ClearData();
        }
        catch (Exception ex)
        {
            lblMsg.Text = ex.Message;
        }
    }
}
