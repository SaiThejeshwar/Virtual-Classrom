﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

public partial class Student_FrmStudentAssignMentSubminimumMaster : System.Web.UI.Page
{
    Cls_StudentAssignmentSubmissionmaster objstudentAssignmentSubmissionmaster = new Cls_StudentAssignmentSubmissionmaster();
    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            if (!IsPostBack)
            {
               
                ShowCourseId();
                ddlLectureid.Items.Insert(0, "--SelectOne--");
            }
        }
        catch (Exception ex)
        {

            lblMsg.Text = ex.Message;
        }
    }
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        try
        {
            if (Session["FileContent"] != null)
            {
                objstudentAssignmentSubmissionmaster.StudentId = Convert.ToInt32(Session["StudentId"]);
                objstudentAssignmentSubmissionmaster.AssignmentText = txtassignment.Text;
                objstudentAssignmentSubmissionmaster.LectureId = Convert.ToInt32(ddlLectureid.SelectedValue);
                objstudentAssignmentSubmissionmaster.Submissionfiletext = Convert.ToString(Session["FileName"]);
                objstudentAssignmentSubmissionmaster.Submissionfile = (byte[])Session["FileContent"];

                int i = objstudentAssignmentSubmissionmaster.InsertStudentAssigmentSubmissionMaster();
                if (i > 0)
                {
                    Cleardata();
                    lblMsg.Text = "Your Assignment Details Submitted..";
                }
                else
                {
                    lblMsg.Text = "Error in Process Try Again..";
                }
            }
            else
                lblMsg.Text = "you must attach the Assignment file";
        }
        catch (Exception ex)
        {

            lblMsg.Text = ex.Message;
        }
    }
    protected void btnClearAll_Click(object sender, EventArgs e)
    {
        Cleardata();
    }
    protected void ddlCourses_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            if (ddlCourses.SelectedIndex != 0)
            {
                DataSet ds = Cls_ExaminationSchedule.ShowLectureId(Convert.ToInt32(ddlCourses.SelectedValue));
                if (ds.Tables[0].Rows.Count != 0)
                {
                    ddlLectureid.DataSource = ds.Tables[0];
                    ddlLectureid.DataTextField = "lecdescription";
                    ddlLectureid.DataValueField = "lectureid";
                    ddlLectureid.DataBind();
                    ddlLectureid.Items.Insert(0, "--SelectOne--");
                }

            }
            else
            {
                ddlLectureid.Items.Clear();
                ddlLectureid.Items.Insert(0, "--SelectOne--");

            }
        }
        catch (Exception ex)
        {

            lblMsg.Text = ex.Message;
        }
    }
    public void ShowCourseId()
    {
        try
        {
            DataSet ds = Cls_StudentAssignmentSubmissionmaster.ShowCourseDetails(Convert.ToInt32(Session["StudentId"]));
            if (ds.Tables[0].Rows.Count != 0)
            {
                ddlCourses.DataSource = ds.Tables[0];
                ddlCourses.DataTextField = "Coursename";
                ddlCourses.DataValueField = "CourseId";
                ddlCourses.DataBind();
            }
            ddlCourses.Items.Insert(0, "--SelectOne--");
        }
        catch (Exception ex)
        {

            lblMsg.Text = ex.Message;
        }
    }
    public void Cleardata()
    {
        txtassignment.Text = "";
        if (ddlLectureid.SelectedIndex != 0)
            ddlLectureid.SelectedIndex = 0;
        if (ddlCourses.SelectedIndex != 0)
            ddlCourses.SelectedIndex = 0;
        lblMsg.Text = "";
    }
}
