﻿using System;
using System.Data;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;
using VirtualClassRoom;

/// <summary>
/// Summary description for Cls_StudentAssignmentSubmissionMaster
/// </summary>
public class Cls_StudentAssignmentSubmissionmaster
{

    private int assignmentID;
    private string assignmentText;
    private int studentId;
    private string submissiondate;
    private int lectureId;
    private byte[] submissionfile;
    private string submissionfiletext;

    // constructor
    public Cls_StudentAssignmentSubmissionmaster()
    {
    }
    public int InsertStudentAssigmentSubmissionMaster()
    {
        try
        {
            SqlParameter[] p = new SqlParameter[5];
            p[0]=new SqlParameter("@AssignmentText",AssignmentText);
            p[1]=new SqlParameter("@StudentId",StudentId);
            p[2]=new SqlParameter("@LectureId",LectureId);
            p[3]=new SqlParameter("@Submissionfile",Submissionfile);
            p[4] = new SqlParameter("@Submissionfiletext", Submissionfiletext);
           
            return SqlHelper.ExecuteNonQuery(Connection.con,CommandType.StoredProcedure,"Sp_StudentAssignmentSubmissionmaster_Insert",p);
        }
        catch (Exception ex)
        {

            throw new ArgumentException(ex.Message);
        }
    }
    public static DataSet ShowCourseDetails(int id)
    {
        try
        {
            DataSet ds = new DataSet();
            SqlParameter p=new SqlParameter("@StudentId",id);
            return SqlHelper.ExecuteDataset(Connection.con,CommandType.StoredProcedure,"Sp_ShowCourseDetailsSelectStudentid",p);
        }
        catch (Exception ex)
        {

            throw new ArgumentException(ex.Message);
        }
    }
   
    public int AssignmentID { get { return assignmentID; } set { assignmentID = value; } }
    public string AssignmentText { get { return assignmentText; } set { assignmentText = value; } }
    public int StudentId { get { return studentId; } set { studentId = value; } }
    public string Submissiondate { get { return submissiondate; } set { submissiondate = value; } }
    public int LectureId { get { return lectureId; } set { lectureId = value; } }
    public byte[] Submissionfile { get { return submissionfile; } set { submissionfile = value; } }
    public string Submissionfiletext { get { return submissionfiletext; } set { submissionfiletext = value; } }



    public static DataSet ShowAssignmetDetailsDownload(int p1)
    {
        try
        {
     
            DataSet ds=new DataSet();
            return SqlHelper.ExecuteDataset(Connection.con, CommandType.Text, "Select * from tbl_StudentAssignmentSubmissionmaster where AssignmentID="+p1);
        }
        catch (Exception ex)
        {

            throw new ArgumentException(ex.Message);
        }
    }

    public static DataSet  ShowFacultyWiseStudentsDispalyew(int p1)
    {
        try
        {
            SqlParameter p = new SqlParameter("@Facultyid", p1);
            DataSet ds=new DataSet();
            return SqlHelper.ExecuteDataset(Connection.con, CommandType.StoredProcedure, "Sp_ShowStudentidselectFacultyid1", p);
        }
        catch (Exception ex)
        {

            throw new ArgumentException(ex.Message);
        }
    }
    public static DataSet ShowRemarksModifieddata(int p1)
    {
        try
        {
            SqlParameter p = new SqlParameter("@Assignmentid", p1);
            DataSet ds = new DataSet();
            return SqlHelper.ExecuteDataset(Connection.con, CommandType.StoredProcedure, "Sp_AssigmentreamarksSelectAssignmentid", p);
        }
        catch (Exception ex)
        {

            throw new ArgumentException(ex.Message);
        }
    }
}
