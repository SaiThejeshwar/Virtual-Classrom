﻿using System;
using System.Data;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;
using VirtualClassRoom;

/// <summary>
/// Summary description for clsStudents
/// </summary>
public class clsStudents
{
	public clsStudents()
	{
		//
		// TODO: Add constructor logic here
		//
	}
        private int studentId;
		private string fName;
		private string mName;
		private string lName;
		private string dOB;
		private string dOR;
		private string address;
		private string emailId;
		private string phoneNo;
		private byte[] imageContent;
		private string imageFile;
        private string userName;
        private string pwd;
        private int courseId;               
        private string paymentType;
        private string paymentno;
        private decimal  payamount;

        public int CourseId { get { return courseId; } set { courseId = value; } }
        public string UserName { get { return userName; } set { userName = value; } }
        public string Pwd { get { return pwd; } set { pwd = value; } }
		public int StudentId {get {return studentId;} set {studentId = value;}}
		public string FName {get {return fName;} set {fName = value;}}
		public string MName {get {return mName;} set {mName = value;}}
		public string LName {get {return lName;} set {lName = value;}}
		public string DOB {get {return dOB;} set {dOB = value;}}
		public string DOR {get {return dOR;} set {dOR = value;}}
		public string Address {get {return address;} set {address = value;}}
		public string EmailId {get {return emailId;} set {emailId = value;}}
		public string PhoneNo {get {return phoneNo;} set {phoneNo = value;}}
        public byte[] ImageContent { get { return imageContent; } set { imageContent = value; } }
		public string ImageFile {get {return imageFile;} set {imageFile = value;}}
        public string PaymentType { get { return paymentType; } set { paymentType = value; } }
        public string Paymentno { get { return paymentno; } set { paymentno = value; } }
        public decimal Payamount { get { return payamount; } set { payamount = value; } }

        public int InsertStudentDetails(out string outMsg,out int id)
        {
            try
            {
                SqlParameter[] p = new SqlParameter[14];
                p[0]=new  SqlParameter("@FName",FName);
                p[1] = new SqlParameter("@MName", MName);
                p[2] = new SqlParameter("@LName", LName);
                p[3] = new SqlParameter("@DOB", DOB);
                p[4] = new SqlParameter("@Address", Address);
                p[5] = new SqlParameter("@EmailId", EmailId);
                p[6] = new SqlParameter("@PhoneNo", PhoneNo);
                p[7] = new SqlParameter("@ImageContent", ImageContent);
                p[8] = new SqlParameter("@ImageFile", ImageFile);
                p[9] = new SqlParameter("@UserName", UserName);
                p[10] = new SqlParameter("@Pwd", Pwd);
                p[11] = new SqlParameter("@CourseId", CourseId);
                p[12] = new SqlParameter("@Out", SqlDbType.VarChar, 150);
                p[12].Direction = ParameterDirection.Output;
                p[13] = new SqlParameter("@StdId", SqlDbType.BigInt);
                p[13].Direction = ParameterDirection.Output;

                int i = SqlHelper.ExecuteNonQuery(Connection.con, CommandType.StoredProcedure, "sp_InsertStudentMaster", p);
                outMsg = p[12].Value.ToString();
                id =Convert.ToInt32(p[13].Value);
                return i;
            }
            catch (Exception ex)
            {
                throw new ArgumentException(ex.Message);
            }
        }

        public DataSet GetAllStudentsData()
        {
            try
            {
                string strCmdText = "select * from tbl_studentMaster";
                return SqlHelper.ExecuteDataset(Connection.con, CommandType.Text, strCmdText);
            }
            catch (Exception ex)
            {
                throw new ArgumentException(ex.Message);
            }
        }

        public DataSet GetStudentsDataByStudentId(int intStudentId)
        {
            try
            {
                string strCmdText = "select * from tbl_studentMaster where StudentId=" + intStudentId;
                return SqlHelper.ExecuteDataset(Connection.con, CommandType.Text, strCmdText);
            }
            catch (Exception ex)
            {
                throw new ArgumentException(ex.Message);
            }
        }

        public int AcceptStudentRegistration(int StdId)
        {
            try
            {
                string strCmdText1 = "update tbl_LoginMaster set [status]=1 where std_fac_Id=" + StdId;
                int i = SqlHelper.ExecuteNonQuery(Connection.con, CommandType.Text, strCmdText1);
                string strCmdText2 = "insert into tbl_StudentOnline(StudentId) values(" + StdId + ")";
                int j = SqlHelper.ExecuteNonQuery(Connection.con, CommandType.Text, strCmdText2);
                if (i == 1 && j == 1)
                    return 1;
                else
                    return 0;
            }
            catch (Exception ex)
            {
                throw new ArgumentException(ex.Message);
            }
        }

        private int courseRegId;
       
        
        private int facultyId;
        private DateTime courseStartDate;
        private DateTime courseEndDate;

        public int CourseRegId { get { return courseRegId; } set { courseRegId = value; } }
        public int FacultyId { get { return facultyId; } set { facultyId = value; } }
        public DateTime CourseStartDate { get { return courseStartDate; } set { courseStartDate = value; } }
        public DateTime CourseEndDate { get { return courseEndDate; } set { courseEndDate = value; } }
	

        public int InsertStudentCourseMaster()
        {
            try
            {
                SqlParameter[] p = new SqlParameter[4];
                p[0] = new SqlParameter("@StudentId", StudentId );
                p[1] = new SqlParameter("@FacultyId", FacultyId);
                p[2] = new SqlParameter("@CourseStartDate", CourseStartDate );
                p[3] = new SqlParameter("@CourseEndDate", CourseEndDate);
                return SqlHelper.ExecuteNonQuery(Connection.con, CommandType.StoredProcedure, "sp_InsertStudentCourseMaster", p);
            }
            catch (Exception ex)
            {
                throw new ArgumentException(ex.Message);
            }
        }
        public int InserCoursefeesdetails()
        {
            try
            {
                SqlParameter []p=new SqlParameter[5];
                p[0]=new SqlParameter("@Studentid",StudentId);
                p[1]=new SqlParameter("@Courseid",CourseId);
                p[2]=new SqlParameter("@PaymentType",PaymentType);
                p[3]=new SqlParameter("@Paymentno",Paymentno);
                p[4] = new SqlParameter("@Payamount", Payamount);
                return SqlHelper.ExecuteNonQuery(Connection.con, CommandType.StoredProcedure, "Sp_CoursefeesDetails_Insert", p);
             
            }
            catch (Exception ex)
            {

                throw new ArgumentException(ex.Message);
            }
        }
}
