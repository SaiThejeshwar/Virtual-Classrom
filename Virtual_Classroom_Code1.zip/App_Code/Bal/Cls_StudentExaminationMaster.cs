﻿using System;
using System.Data;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;
using VirtualClassRoom;

/// <summary>
/// Summary description for Cls_StudentExaminationMaster
/// </summary>
public class Cls_StudentExaminationMaster
{

    private int studentExamId;
    private DateTime  examAttendeddate;
    private int examinationId;
    private string examResult;
    private string examAggregate;
    private int studentId;

    // constructor
    public Cls_StudentExaminationMaster()
    {
    }
    public int InsertStudentExaminaion()
    {
        try
        {
            SqlParameter []p=new SqlParameter[4];
            p[0]=new SqlParameter("@Examdate",ExamAttendeddate);
            p[1]=new SqlParameter("@Examinaionid",ExaminationId);
            p[2]=new SqlParameter("@Studentid",StudentId);
            p[3] = new SqlParameter("@studentExamid",SqlDbType.BigInt) ;
            p[3].Direction = ParameterDirection.Output;
            SqlHelper.ExecuteNonQuery(Connection.con, CommandType.StoredProcedure, "Sp_InsertExaminationMaster", p);
            return Convert.ToInt32(p[3].Value);
        }
        catch (Exception ex)
        {

            throw new ArgumentException(ex.Message);
        }
    }
    public static DataSet ShowExaminationID(int id)
    {
        try
        {
            SqlParameter p=new SqlParameter("@Facultyid",id);
            return SqlHelper.ExecuteDataset(Connection.con,CommandType.StoredProcedure,"Sp_ExaminationIdSelectFacultyId",p);
        }
        catch (Exception ex)
        {

            throw new ArgumentException(ex.Message);
        }
    }
    public static DataSet ShowStudentId(int id)
    {
        try
        {
            SqlParameter p = new SqlParameter("@Examinationid", id);
            return SqlHelper.ExecuteDataset(Connection.con, CommandType.StoredProcedure, "Sp_StudentidSelectExaminationId", p);
     
        }
        catch (Exception ex)
        {

            throw new ArgumentException(ex.Message);
        }
    }

    public int StudentExamId { get { return studentExamId; } set { studentExamId = value; } }
    public DateTime ExamAttendeddate { get { return examAttendeddate; } set { examAttendeddate = value; } }
    public int ExaminationId { get { return examinationId; } set { examinationId = value; } }
    public string ExamResult { get { return examResult; } set { examResult = value; } }
    public string ExamAggregate { get { return examAggregate; } set { examAggregate = value; } }
    public int StudentId { get { return studentId; } set { studentId = value; } }

    public static void UpdatestudentMarks(int id, int marks)
    {
        try
        {
            SqlHelper.ExecuteDataset(Connection.con, CommandType.Text, "update tbl_StudentExaminationMaster set ExamResult =" + marks + " where studentExamid=" + id);
        }
        catch (Exception ex)
        {

            throw new ArgumentException(ex.Message);
        }
    }

    public static void ShowExamresults(int p1)
    {
        try
        {
            SqlParameter p = new SqlParameter("studentid", p1);
            SqlHelper.ExecuteNonQuery(Connection.con, CommandType.StoredProcedure, "Sp_results_Insert", p);
        }
        catch (Exception ex)
        {
            throw new ArgumentException(ex.Message);
        }
    }
}
