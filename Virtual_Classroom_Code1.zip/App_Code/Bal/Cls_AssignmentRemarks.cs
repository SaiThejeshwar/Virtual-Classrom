﻿using System;
using System.Data;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;
using VirtualClassRoom;

/// <summary>
/// Summary description for Cls_AssignmentRemarks
/// </summary>
public class Cls_AssignmentRemarks
{

    private int assignmentID;
    private int facultyId;
    private string remarkstoStudent;

    // constructor
    public Cls_AssignmentRemarks()
    {
    }
    public int InsertAssignmentRemarks()
    {
        try
        {
            SqlParameter[] p=new SqlParameter[3];
            p[0]=new SqlParameter("@AssignmentID",AssignmentID);
            p[1]=new SqlParameter("@FacultyId",FacultyId);
            p[2] = new SqlParameter("@RemarkstoStudent", RemarkstoStudent);
            return SqlHelper.ExecuteNonQuery(Connection.con,CommandType.StoredProcedure,"Sp_AssignmentRemarks_Insert",p);
        }
        catch (Exception ex)
        {

            throw new ArgumentException(ex.Message);
        }
    }
    public static DataSet ShowStudentWiseRemarks(int id )
    {
        try
        {
            SqlParameter p = new SqlParameter("@studentid",id);
            DataSet ds = new DataSet();
            return SqlHelper.ExecuteDataset(Connection.con, CommandType.StoredProcedure, "Sp_ShowStudentAssgienmentdetailsStudenidwise", p);
        }
        catch (Exception ex)
        {

            throw new ArgumentException(ex.Message);
        }
    }

    public int AssignmentID { get { return assignmentID; } set { assignmentID = value; } }
    public int FacultyId { get { return facultyId; } set { facultyId = value; } }
    public string RemarkstoStudent { get { return remarkstoStudent; } set { remarkstoStudent = value; } }
}
