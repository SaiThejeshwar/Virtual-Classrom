﻿using System;
using System.Data;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;
using VirtualClassRoom;
/// <summary>
/// Summary description for clsCourses
/// </summary>
public class clsCourses
{
	public clsCourses()
	{
		//
		// TODO: Add constructor logic here
		//
	}

        private int courseId;
		private string courseName;
		private string description;
		private string duration;
		private string courseFileName;
		private byte[] courseFileContent;
        private int noOfLectures;
        private decimal coursefees;

        public int NoOfLectures { get { return noOfLectures; } set { noOfLectures = value; } }
		public int CourseId {get {return courseId;} set {courseId = value;}}
		public string CourseName {get {return courseName;} set {courseName = value;}}
		public string Description {get {return description;} set {description = value;}}
		public string Duration {get {return duration;} set {duration = value;}}
		public string CourseFileName {get {return courseFileName;} set {courseFileName = value;}}
        public decimal  CourseFees { get { return coursefees; } set { coursefees = value; } }
        public byte[] CourseFileContent { get { return courseFileContent; } set { courseFileContent = value; } }

        public int InsertCourseDetails()
        {
            try
            {
                SqlParameter[] p = new SqlParameter[7];
                p[0] = new SqlParameter("@CourseName", CourseName);
                p[1] = new SqlParameter("@Description", Description);
                p[2] = new SqlParameter("@Duration", Duration);
                p[3] = new SqlParameter("@CourseFileName", CourseFileName);
                p[4] = new SqlParameter("@CourseFileContent", CourseFileContent);
                p[5] = new SqlParameter("@NoOfLectures", NoOfLectures);
                p[6] = new SqlParameter("@CourseFees", CourseFees);
                return SqlHelper.ExecuteNonQuery(Connection.con, CommandType.StoredProcedure, "sp_InsertCourseMaster", p);
            }
            catch (Exception ex)
            {
                throw new ArgumentException(ex.Message);
            }
        }

        public DataSet GetAllCoursesDetails()
        {
            try
            {
                string strCmdText = "select * from tbl_CourseMaster";
                return SqlHelper.ExecuteDataset(Connection.con, CommandType.StoredProcedure, strCmdText);
            }
            catch (Exception ex)
            {
                throw new ArgumentException(ex.Message);
            }
        }

        public DataSet GetCoursesDetailsByCourseId(int intCourseId)
        {
            try
            {
                string strCmdText = "select * from tbl_CourseMaster where CourseId=" + intCourseId;
                return SqlHelper.ExecuteDataset(Connection.con, CommandType.Text, strCmdText);
            }
            catch (Exception ex)
            {
                throw new ArgumentException(ex.Message);
            }
        }

        public int UpdateCourseDetails()
        {
            try
            {
                SqlParameter[] p = new SqlParameter[7];
                p[0] = new SqlParameter("@CourseId", CourseId);
                p[1] = new SqlParameter("@CourseName", CourseName);
                p[2] = new SqlParameter("@Description", Description);
                p[3] = new SqlParameter("@Duration", Duration);
                p[4] = new SqlParameter("@CourseFileName", CourseFileName);
                p[5] = new SqlParameter("@CourseFileContent", CourseFileContent);
                p[6] = new SqlParameter("@NoOfLectures", NoOfLectures);
                return SqlHelper.ExecuteNonQuery(Connection.con, CommandType.StoredProcedure, "sp_UpdateCourseMaster", p);
            }
            catch (Exception ex)
            {
                throw new ArgumentException(ex.Message);
            }
        }

        private int lectureId;
        private DateTime dOR;
        private int facultyId;
        private string lecDescription;
        private string lecAudioFileName;
        private byte[] lecAudioFileContent;
        private string lecVideoFileName;
        private byte[] lecVideoFileContent;
        private string lecPowerPointFileName;
        private byte[] lecPowerPointFileContent;
        private string lecDocFileName;
        private byte[] lecDocFileContent;
        private string lecAssignmentFileName;
        private byte[] lecAssignmentFileContent;
        private string lecDurationTime;

        public int LectureId { get { return lectureId; } set { lectureId = value; } }
        public DateTime DOR { get { return dOR; } set { dOR = value; } }
       
        public int FacultyId { get { return facultyId; } set { facultyId = value; } }
        public string LecDescription { get { return lecDescription; } set { lecDescription = value; } }
        public string LecAudioFileName { get { return lecAudioFileName; } set { lecAudioFileName = value; } }
        public byte[] LecAudioFileContent { get { return lecAudioFileContent; } set { lecAudioFileContent = value; } }
        public string LecVideoFileName { get { return lecVideoFileName; } set { lecVideoFileName = value; } }
        public byte[] LecVideoFileContent { get { return lecVideoFileContent; } set { lecVideoFileContent = value; } }
        public string LecPowerPointFileName { get { return lecPowerPointFileName; } set { lecPowerPointFileName = value; } }
        public byte[] LecPowerPointFileContent { get { return lecPowerPointFileContent; } set { lecPowerPointFileContent = value; } }
        public string LecDocFileName { get { return lecDocFileName; } set { lecDocFileName = value; } }
        public byte[] LecDocFileContent { get { return lecDocFileContent; } set { lecDocFileContent = value; } }
        public string LecAssignmentFileName { get { return lecAssignmentFileName; } set { lecAssignmentFileName = value; } }
        public byte[] LecAssignmentFileContent { get { return lecAssignmentFileContent; } set { lecAssignmentFileContent = value; } }
        public string LecDurationTime { get { return lecDurationTime; } set { lecDurationTime = value; } }

        public int InsertCourselecturesMasterData()
        {

            try
            {
                SqlParameter[] p = new SqlParameter[14];
                p[0] = new SqlParameter("@CourseId", CourseId);
                p[1] = new SqlParameter("@FacultyId", FacultyId);
                p[2] = new SqlParameter("@LecDescription", LecDescription);
                p[3] = new SqlParameter("@LecAudioFileName", LecAudioFileName);
                p[4] = new SqlParameter("@LecAudioFileContent", LecAudioFileContent);
                p[5] = new SqlParameter("@LecVideoFileName", LecVideoFileName);
                p[6] = new SqlParameter("@LecVideoFileContent", LecVideoFileContent);
                p[7] = new SqlParameter("@LecPowerPointFileName", LecPowerPointFileName);
                p[8] = new SqlParameter("@LecPowerPointFileContent", LecPowerPointFileContent);
                p[9] = new SqlParameter("@LecDocFileName", LecDocFileName);
                p[10] = new SqlParameter("@LecDocFileContent", LecDocFileContent);
                p[11] = new SqlParameter("@LecAssignmentFileName", LecAssignmentFileName);
                p[12] = new SqlParameter("@LecAssignmentFileContent", LecAssignmentFileContent);
                p[13] = new SqlParameter("@LecDurationTime", LecDurationTime);

                return SqlHelper.ExecuteNonQuery(Connection.con, CommandType.StoredProcedure, "sp_InsertCourseLectureMaster", p);
            }
            catch (Exception ex)
            {
                throw new ArgumentException(ex.Message);
            }
        }

        public int UpdateCourselecturesMasterData()
        {
            try
            {
                SqlParameter[] p = new SqlParameter[13];
                p[0] = new SqlParameter("@LectureId", LectureId);
               
                p[1] = new SqlParameter("@LecDescription", LecDescription);
                p[2] = new SqlParameter("@LecAudioFileName", LecAudioFileName);
                p[3] = new SqlParameter("@LecAudioFileContent", LecAudioFileContent);
                p[4] = new SqlParameter("@LecVideoFileName", LecVideoFileName);
                p[5] = new SqlParameter("@LecVideoFileContent", LecVideoFileContent);
                p[6] = new SqlParameter("@LecPowerPointFileName", LecPowerPointFileName);
                p[7] = new SqlParameter("@LecPowerPointFileContent", LecPowerPointFileContent);
                p[8] = new SqlParameter("@LecDocFileName", LecDocFileName);
                p[9] = new SqlParameter("@LecDocFileContent", LecDocFileContent);
                p[10] = new SqlParameter("@LecAssignmentFileName", LecAssignmentFileName);
                p[11] = new SqlParameter("@LecAssignmentFileContent", LecAssignmentFileContent);
                p[12] = new SqlParameter("@LecDurationTime", LecDurationTime);

                return SqlHelper.ExecuteNonQuery(Connection.con, CommandType.StoredProcedure, "sp_UpdateCourseLectureMaster", p);
            }
            catch (Exception ex)
            {
                throw new ArgumentException(ex.Message);
            }
        }

        public static DataSet ShowFeesDetailsCourseWise(int p1)
        {
            try
            {
                DataSet ds = new DataSet();
                SqlParameter  p = new SqlParameter("@studentid", p1);
               
                return SqlHelper.ExecuteDataset(Connection.con, CommandType.StoredProcedure, "Sp_coursefeesdetails", p);
            }
            catch (Exception ex)
            {

                throw new ArgumentException(ex.Message);
            }
        }
        public static DataSet ShowStudentpayfeesdetails(int p1)
        {
            try
            {
                DataSet ds = new DataSet();
                SqlParameter p = new SqlParameter("@studentid", p1);

                return SqlHelper.ExecuteDataset(Connection.con, CommandType.StoredProcedure, "Sp_Studentpayfeesdetails", p);
            }
            catch (Exception ex)
            {
                throw new ArgumentException(ex.Message);
            }
        }

        public static DataSet GetSearchedCourse(string p)
        {
            try
            {
                string str = "SELECT [CourseName] as Course, [Description], [Duration], [CourseFees] as Fees FROM [tbl_CourseMaster] WHERE ([CourseName] LIKE '%"+p+"%')";
                return SqlHelper.ExecuteDataset(Connection.con, CommandType.Text, str);
            }
            catch (Exception ex)
            {
                throw new ArgumentException(ex.Message);
            }
        }

        public static DataSet SearchFacultyData(string p)
        {
            try
            {
                string str = "select FName+' '+MName+' '+LName as [Name],Experience ,EmailId,PhoneNo,[Address] from tbl_FacultyMaster where (FName Like '%" + p + "%') or (MName like '%" + p + "%') or (LName like '%" + p + "%')";
                return SqlHelper.ExecuteDataset(Connection.con, CommandType.Text, str);
            }
            catch (Exception ex)
            {
                throw new ArgumentException(ex.Message);
            }
        }

        public static DataSet SearchStudentData(string p)
        {
            try
            {
                string str = "select FName+' '+MName+' '+LName as [Name],EmailId,PhoneNo,[Address] from tbl_StudentMaster where (FName Like '%" + p + "%') or (MName like '%" + p + "%') or (LName like '%" + p + "%')";
                return SqlHelper.ExecuteDataset(Connection.con, CommandType.Text, str);
            }
            catch (Exception ex)
            {
                throw new ArgumentException(ex.Message);
            }
        }
}
