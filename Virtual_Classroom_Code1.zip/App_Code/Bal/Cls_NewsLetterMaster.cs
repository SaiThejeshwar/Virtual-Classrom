﻿using System;
using System.Data;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;
using VirtualClassRoom;

/// <summary>
/// Summary description for Cls_NewsLetterMaster
/// </summary>
public class Cls_NewsLetterMaster
{

    private int newsLetterId;
    private string newsLetterText;
    private byte[] letterUploadfile;
    private string letterUploadfiletext;
    private string date;
    private int faculityId;

    // constructor
    public Cls_NewsLetterMaster()
    {
    }
    public int InsertNewsLetterMaster()
    {
        try
        {
            SqlParameter []p=new SqlParameter[4];
            p[0]=new SqlParameter("@NewsLetterText",NewsLetterText);
            p[1]=new SqlParameter("@LetterUploadfile",LetterUploadfile);
            p[2]=new SqlParameter("@LetterUploadfiletext",LetterUploadfiletext);
            p[3] = new SqlParameter("@FaculityId", FaculityId);
            return SqlHelper.ExecuteNonQuery(Connection.con, CommandType.StoredProcedure, "Sp_NewsLetterMaster_Insert", p);

        }
        catch (Exception ex)
        {

            throw new ArgumentException(ex.Message);
        }
    }
 

    public int NewsLetterId { get { return newsLetterId; } set { newsLetterId = value; } }
    public string NewsLetterText { get { return newsLetterText; } set { newsLetterText = value; } }
    public byte[] LetterUploadfile { get { return letterUploadfile; } set { letterUploadfile = value; } }
    public string LetterUploadfiletext { get { return letterUploadfiletext; } set { letterUploadfiletext = value; } }
    public string Date { get { return date; } set { date = value; } }
    public int FaculityId { get { return faculityId; } set { faculityId = value; } }

    public static DataSet  ShowLectureMaster(int p1)
    {
        try
        {
            SqlParameter p = new SqlParameter("@studentid", p1);
            DataSet ds = new DataSet();
          return   SqlHelper.ExecuteDataset(Connection.con, CommandType.StoredProcedure, "Sp_ShowCourseLectureMaster", p);
        }
        catch (Exception ex)
        {

            throw new ArgumentException(ex.Message);
        }
    }
    public static DataSet ShowLectureMasterAlldetails()
    {
        try
        {
            
            DataSet ds = new DataSet();
            return SqlHelper.ExecuteDataset(Connection.con, CommandType.StoredProcedure, "Sp_ShowCourseLectureMaster");
        }
        catch (Exception ex)
        {

            throw new ArgumentException(ex.Message);
        }
    }
    public static DataSet showLectureMasterDetailsDownloading(int id)
    {
        try
        {
            SqlParameter p = new SqlParameter("@LectureId", id);
            DataSet ds = new DataSet();
            return SqlHelper.ExecuteDataset(Connection.con, CommandType.StoredProcedure, "Sp_DownloadsCourseLectureDetails", p);
        }
        catch (Exception ex)
        {

            throw new ArgumentException(ex.Message);
        }
    }

    public static DataSet ShowFacultyNotice(int Id)
    {
        try
        {
          return  SqlHelper.ExecuteDataset(Connection.con, CommandType.Text, "select * from tbl_FacultyNoticesMaster where Noticeid=" + Id);
        }
        catch (Exception ex)
        {

            throw new ArgumentException(ex.Message);
        }
    }

    public static DataSet ShowNewsLetterMaster(int Id)
    {
        try
        {
            return SqlHelper.ExecuteDataset(Connection.con, CommandType.Text, "select * from tbl_NewsLetterMaster where  newsletterId=" + Id);
        }
        catch (Exception ex)
        {

            throw new ArgumentException(ex.Message);
        }
      
    }
}
