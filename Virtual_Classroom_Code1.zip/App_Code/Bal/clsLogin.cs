﻿using System;
using System.Data;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;
using VirtualClassRoom;
/// <summary>
/// Summary description for clsLogin
/// </summary>
public class clsLogin
{

    public clsLogin()
    {
        //
        // TODO: Add constructor logic here
        //
    }

    public static string LoginName { get; set; }
    public static string Password { get; set; }
    public static string Role { get; set; }
    DataSet ds = null;

    public string GetUserLogin(out int Id)
    {
        try
        {
            SqlParameter[] p = new SqlParameter[4];

            p[0] = new SqlParameter("@LoginName", LoginName);
            p[1] = new SqlParameter("@Password", Password);
            p[2] = new SqlParameter("@Role", SqlDbType.VarChar, 50);
            p[2].Direction = ParameterDirection.Output;
            p[3] = new SqlParameter("@Std_Fac_Id", SqlDbType.Int);
            p[3].Direction = ParameterDirection.Output;

            SqlHelper.ExecuteNonQuery(Connection.con, CommandType.StoredProcedure, "spLoginChecking", p);
            Role = Convert.ToString(p[2].Value);
            if (Role != "NoUser")
                Id = Convert.ToInt32(p[3].Value);
            else
                Id = 0;
            return Role;
        }
        catch (Exception ex)
        {
            throw new ArgumentException(ex.Message);
        }
    }

    public static void ActiveFacultyOnlineStatus(int Id)
    {
        try
        {
            string str = "Update tbl_FacultyOnline set [status]=1 where FacultyId=" + Id;
            SqlHelper.ExecuteNonQuery(Connection.con, CommandType.Text ,str );
        }
        catch (Exception ex)
        {
            throw new ArgumentException(ex.Message);
        }
    }

    public static void InActiveFacultyOnlineStatus(int Id)
    {
        try
        {
            string str = "Update tbl_FacultyOnline set [status]=0 where FacultyId=" + Id;
            SqlHelper.ExecuteNonQuery(Connection.con, CommandType.Text, str);
        }
        catch (Exception ex)
        {
            throw new ArgumentException(ex.Message);
        }
    }

    public static void ActiveStudentOnlineStatus(int Id)
    {
        try
        {
            string str = "Update tbl_StudentOnline set [status]=1 where StudentId=" + Id;
            SqlHelper.ExecuteNonQuery(Connection.con, CommandType.Text, str);
        }
        catch (Exception ex)
        {
            throw new ArgumentException(ex.Message);
        }
    }

    public static void InActiveStudentOnlineStatus(int Id)
    {
        try
        {
            string str = "Update tbl_StudentOnline set [status]=0 where StudentId=" + Id;
            SqlHelper.ExecuteNonQuery(Connection.con, CommandType.Text, str);
        }
        catch (Exception ex)
        {
            throw new ArgumentException(ex.Message);
        }
    }

    public static DataSet GetOnlineFacultyData()
    {
        try
        {
            return SqlHelper.ExecuteDataset(Connection.con, CommandType.StoredProcedure, "sp_GetOnlineFacultyData");
        }
        catch (Exception ex)
        {
            throw new ArgumentException(ex.Message);
        }
    }

    public static DataSet GetOnlineStudentData()
    {
        try
        {
            return SqlHelper.ExecuteDataset(Connection.con, CommandType.StoredProcedure, "sp_GetOnlineStudentData");
        }
        catch (Exception ex)
        {
            throw new ArgumentException(ex.Message);
        }
    }

}
