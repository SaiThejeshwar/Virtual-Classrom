﻿using System;
using System.Data;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;
using VirtualClassRoom;
/// <summary>
/// Summary description for Cls_Common
/// </summary>
public class Cls_Common
{

    private int studentId;
    private string studentName;
    private string mName;
    private string lName;
    private string dateOfBirth;
    private string dOR;
    private string address;
    private string emailId;
    private string phoneNo;
    private byte[] imageContent;
    private string imageFile;
    private int courseId;
    private string facultyname;

    // constructor
    public Cls_Common()
    {
    }
    
    public string FacultyName { get { return facultyname; } set { facultyname = value; } }
    public int StudentId { get { return studentId; } set { studentId = value; } }
    public string StudentName { get { return studentName; } set { studentName = value; } }
    public string MName { get { return mName; } set { mName = value; } }
    public string LName { get { return lName; } set { lName = value; } }
    public string DateOfBirth { get { return dateOfBirth; } set { dateOfBirth = value; } }
    public string DOR { get { return dOR; } set { dOR = value; } }
    public string Address { get { return address; } set { address = value; } }
    public string EmailId { get { return emailId; } set { emailId = value; } }
    public string PhoneNo { get { return phoneNo; } set { phoneNo = value; } }
    public byte[] ImageContent { get { return imageContent; } set { imageContent = value; } }
    public string ImageFile { get { return imageFile; } set { imageFile = value; } }
    public int CourseId { get { return courseId; } set { courseId = value; } }

    public DataSet ShowStudentReport()
    {
        try
        {
            DataSet ds = new DataSet();
            return SqlHelper.ExecuteDataset(Connection.con, CommandType.Text, "select  FName as StudentName,convert(varchar(20), DoB,103)as DateOfBirth ,Address,PhoneNo,EmailId,Imagecontent from tbl_studentmaster");

        }
        catch (Exception ex)
        {

            throw new ArgumentException(ex.Message);
        }
    }

    public DataSet ShowFacultyReport()
    {
        try
        {
            DataSet ds = new DataSet();
            return SqlHelper.ExecuteDataset(Connection.con, CommandType.Text, "select  FName as FacultyName,convert(varchar(20), DoB,103)as DateOfBirth ,Address,PhoneNo,EmailId,Imagecontent from tbl_facultymaster");

        }
        catch (Exception ex)
        {

            throw new ArgumentException(ex.Message);
        }
    }
}
