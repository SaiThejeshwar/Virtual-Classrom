﻿using System;
using System.Data;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;
using VirtualClassRoom;


/// <summary>
/// Summary description for clsFaculty
/// </summary>
public class clsFaculty
{
	public clsFaculty()
	{
		//
		// TODO: Add constructor logic here
		//
	}
        private int facultyId;
		private string fName;
		private string mName;
		private string lName;
		private string dOB;
		private string dOR;
		private string address;
		private string emailId;
		private string phoneNo;
		private byte[] imageContent;
		private string imageFile;
		private string experience;
		private string remarks;
        private string userName;
        private string pwd;
        private int courseId;
		private string descByFaculty;
        private int achievementId;
        private string description;
        private string spRemarks;

        public string UserName { get { return userName; } set { userName = value; } }
        public string Pwd { get { return pwd; } set { pwd = value; } }
		public int FacultyId {get {return facultyId;} set {facultyId = value;}}
		public string FName {get {return fName;} set {fName = value;}}
		public string MName {get {return mName;} set {mName = value;}}
		public string LName {get {return lName;} set {lName = value;}}
		public string DOB {get {return dOB;} set {dOB = value;}}
		public string DOR {get {return dOR;} set {dOR = value;}}
		public string Address {get {return address;} set {address = value;}}
		public string EmailId {get {return emailId;} set {emailId = value;}}
		public string PhoneNo {get {return phoneNo;} set {phoneNo = value;}}
        public byte[] ImageContent { get { return imageContent; } set { imageContent = value; } }
		public string ImageFile {get {return imageFile;} set {imageFile = value;}}
		public string Experience {get {return experience;} set {experience = value;}}
		public string Remarks {get {return remarks;} set {remarks = value;}}
        public string SpRemarks { get { return spRemarks; } set { spRemarks = value; } }
		public int CourseId {get {return courseId;} set {courseId = value;}}
		public string DescByFaculty {get {return descByFaculty;} set {descByFaculty = value;}}
        public int AchievementId { get { return achievementId; } set { achievementId = value; } }
        public string Description { get { return description; } set { description = value; } }

        public int InsertFacultyDetails(out string outMsg)
        {
            try
            {
                SqlParameter[] p = new SqlParameter[14];
                p[0] = new SqlParameter("@FName", FName);
                p[1] = new SqlParameter("@MName", MName);
                p[2] = new SqlParameter("@LName", LName);
                p[3] = new SqlParameter("@DOB", DOB);
                p[4] = new SqlParameter("@Address", Address);
                p[5] = new SqlParameter("@EmailId", EmailId);
                p[6] = new SqlParameter("@PhoneNo", PhoneNo);
                p[7] = new SqlParameter("@ImageContent", ImageContent);
                p[8] = new SqlParameter("@ImageFile", ImageFile);
                p[9] = new SqlParameter("@UserName", UserName);
                p[10] = new SqlParameter("@Pwd", Pwd);
                p[11] = new SqlParameter("@Experience", Experience);
                p[12] = new SqlParameter("@Remarks", Remarks);
                p[13] = new SqlParameter("@Out", SqlDbType.VarChar, 150);
                p[13].Direction = ParameterDirection.Output;

                int i = SqlHelper.ExecuteNonQuery(Connection.con, CommandType.StoredProcedure, "sp_InsertFacultyMaster", p);
                outMsg = p[13].Value.ToString();
                return i;
            }
            catch (Exception ex)
            {
                throw new ArgumentException(ex.Message);
            }
        }

        public DataSet GetAllFacultyData()
        {
            try
            {
                string strCmdText = "select * from tbl_FacultyMaster";
                return SqlHelper.ExecuteDataset(Connection.con, CommandType.Text, strCmdText);
            }
            catch (Exception ex)
            {
                throw new ArgumentException(ex.Message);
            }
        }
        
        public DataSet GetFacultyDataByFacultyId(int intFacultyId)
        {
            try
            {
                string strCmdText = "select * from tbl_FacultyMaster where FacultyId=" + intFacultyId;
                return SqlHelper.ExecuteDataset(Connection.con, CommandType.Text, strCmdText);
            }
            catch (Exception ex)
            {
                throw new ArgumentException(ex.Message);
            }
        }

        public int InsertCourseandAchievementsByFaculty()
        {
            try
            {
                SqlParameter[] p = new SqlParameter[5];
                p[0] = new SqlParameter("@CourseId", CourseId);
                p[1] = new SqlParameter("@FacultyId", FacultyId);
                p[2] = new SqlParameter("@DescByFaculty", DescByFaculty);
                p[3] = new SqlParameter("@Description", Description);
                p[4] = new SqlParameter("@Remarks", SpRemarks);

                return SqlHelper.ExecuteNonQuery(Connection.con, CommandType.StoredProcedure, "sp_InsertCourseandAchievementsByFaculty", p);
            }
            catch (Exception ex)
            {
                throw new ArgumentException(ex.Message);
            }
        }

        private int noticeId;
        private string noticeDate;
        
        private string noticeText;
        private string noticeFileName;
        private byte[] noticeFileContent;

        public int NoticeId { get { return noticeId; } set { noticeId = value; } }
        public string NoticeDate { get { return noticeDate; } set { noticeDate = value; } }
       
        public string NoticeText { get { return noticeText; } set { noticeText = value; } }
        public string NoticeFileName { get { return noticeFileName; } set { noticeFileName = value; } }
        public byte[] NoticeFileContent { get { return noticeFileContent; } set { noticeFileContent = value; } }

        public int InsertFacultyNotices()
        {
            try
            {
                SqlParameter[] p = new SqlParameter[4];
                p[0] = new SqlParameter("@FacultyId", FacultyId);
                p[1] = new SqlParameter("@NoticeText", NoticeText);
                p[2] = new SqlParameter("@NoticeFileName", NoticeFileName);
                p[3] = new SqlParameter("@NoticeFileContent", NoticeFileContent);
                return SqlHelper.ExecuteNonQuery(Connection.con, CommandType.StoredProcedure, "sp_InsertFacultyNoticesMaster", p);
            }
            catch (Exception ex)
            {
                throw new ArgumentException(ex.Message);
            }
        }

        public int AcceptFacultyRegistration(int FacId)
        {
            try
            {
                string strCmdText1 = "update tbl_LoginMaster set [status]=1 where std_fac_Id=" + FacId;
                int i = SqlHelper.ExecuteNonQuery(Connection.con, CommandType.Text, strCmdText1);

                string strCmdText2 = "insert into tbl_FacultyOnline(FacultyId) values("+FacId+")";
                int j = SqlHelper.ExecuteNonQuery(Connection.con, CommandType.Text, strCmdText2);
                if (i > 0 && j > 0)
                    return 1;
                else
                    return 0;
            }
            catch (Exception ex)
            {
                throw new ArgumentException(ex.Message);
            }
        }

        public DataSet GetCoursesByFacultyId(int FacId)
        {
            try
            {
                string strCmdText = "select (select CourseName from tbl_CourseMaster cm where cm.CourseId=cf.CourseId) as CourseName,DescByFaculty as Description from tbl_CourseFacultyMaster cf where FacultyId=" + FacId;
                return SqlHelper.ExecuteDataset(Connection.con, CommandType.Text, strCmdText);
            }
            catch (Exception ex)
            {
                throw new ArgumentException(ex.Message);
            }
        }

        public DataSet GetAchievementsByFacultyId(int FacId)
        {
            try
            {
                string strCmdText = "select Description,Remarks from tbl_FacultyAchievements where FacultyId=" + FacId;
                return SqlHelper.ExecuteDataset(Connection.con, CommandType.Text , strCmdText);
            }
            catch (Exception ex)
            {
                throw new ArgumentException(ex.Message);
            }
        }

        public static DataSet GetFacultyLectureDataByLecId(int Id)
        {
            try
            {
                string strCmdText = "select * from tbl_CourseLectureMaster where LectureId=" + Id;
                return SqlHelper.ExecuteDataset(Connection.con, CommandType.Text, strCmdText);
            }
            catch (Exception ex)
            {
                throw new ArgumentException(ex.Message);
            } 
        }

        public static DataSet GetFacultyDataByCourseId(int CourseId)
        {
            try 
            {
                SqlParameter[] p = new SqlParameter[1];
                p[0] = new SqlParameter("@CourseId", CourseId);
                return SqlHelper.ExecuteDataset(Connection.con, CommandType.StoredProcedure, "sp_GetFacultyByCourseId", p);
            }
            catch (Exception ex)
            {
                throw new ArgumentException(ex.Message);
            } 
        }
}
