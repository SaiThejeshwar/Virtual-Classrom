﻿using System;
using System.Data;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;
using VirtualClassRoom;

/// <summary>
/// Summary description for Cls_StudentExaminationDetails
/// </summary>
public class Cls_StudentExaminationDetails
{

    private int studentExamId;
    private int questionId;
    private string answers;
    private bool  correctAndWrongBit;

    // constructor
    public Cls_StudentExaminationDetails()
    {
    }
    public static DataSet showCourseDetails(int id)
    {
        try
        {
            SqlParameter p = new SqlParameter("@StudentId", id);
            DataSet ds = new DataSet();
            return SqlHelper.ExecuteDataset(Connection.con, CommandType.StoredProcedure, "Sp_CourseDetailsSelectStudentId",p);
        }
        catch (Exception ex)
        {

            throw new ArgumentException(ex.Message);
        }
    }
    public static DataSet ShowFacultyDetails(int id,int Stuid)
    {
        try
        {
            SqlParameter[] p = new SqlParameter[2];
            p[0]=new SqlParameter("@Courseid", id);
            p[1] = new SqlParameter("@Studentid", Stuid);
            DataSet ds = new DataSet();
            return SqlHelper.ExecuteDataset(Connection.con, CommandType.StoredProcedure, "Sp_FacultyDetailsSelectCourseid",p);
        }
        catch (Exception ex)
        {

            throw new ArgumentException(ex.Message);
        }
    }
    public static DataSet showExamDetails(int id)
    {
        try
        {
            SqlParameter p = new SqlParameter("@Facultyid", id);
            DataSet ds = new DataSet();
            return SqlHelper.ExecuteDataset(Connection.con, CommandType.StoredProcedure, "Sp_ExaminationTextdetailsFacultyWise", p);
        }
        catch (Exception ex)
        {

            throw new ArgumentException(ex.Message);
        }
    }
    public static DataSet showExamDetailsStudentWise(int id,int StudentId)
    {
        try
        {
            SqlParameter[] p = new SqlParameter[2];
            p[0]=new SqlParameter("@Facultyid", id);
            p[1] = new SqlParameter("@StudentId", StudentId);
            DataSet ds = new DataSet();
            return SqlHelper.ExecuteDataset(Connection.con, CommandType.StoredProcedure, "Sp_ExaminationTextdetailsFacultyWiseandStudentSelect", p);
        }
        catch (Exception ex)
        {

            throw new ArgumentException(ex.Message);
        }
    }

    public static DataSet ShowExaminationAllDetails(int id)
    {
        try
        {
            SqlParameter p = new SqlParameter("@StudentExaminationid", id);
            DataSet ds = new DataSet();
            return SqlHelper.ExecuteDataset(Connection.con, CommandType.StoredProcedure, "Sp_SelectExaminationdetails",p);
        }
        catch (Exception ex)
        {

            throw new ArgumentException(ex.Message);
        }
    }
    

    public int StudentExamId { get { return studentExamId; } set { studentExamId = value; } }
    public int QuestionId { get { return questionId; } set { questionId = value; } }
    public string Answers { get { return answers; } set { answers = value; } }
    public bool CorrectAndWrongBit { get { return correctAndWrongBit; } set { correctAndWrongBit = value; } }

    public int InsertStudentExaminationDetails(int id, string  lblQuestionID, string text, bool p1)
    {
        SqlParameter[] p = new SqlParameter[4];
        p[0] = new SqlParameter("@StudentExamId", id );
        p[1] = new SqlParameter("@QuestionId", lblQuestionID);
        p[2] = new SqlParameter("@Answers", text);
        p[3] = new SqlParameter("@CorrectAndWrongBit", p1);
        return SqlHelper.ExecuteNonQuery(Connection.con, CommandType.StoredProcedure, "Sp_StudentExaminationDetails_Insert", p);

    }

   
    public static DataSet ShowStudentExaminationMaster(int id)
    {
        try
        {
            DataSet ds = new DataSet();
            return SqlHelper.ExecuteDataset(Connection.con, CommandType.Text, "select * from tbl_StudentExaminationMaster where StudentExamId="+id);
        }
        catch (Exception ex)
        {

            throw new ArgumentException(ex.Message);
        }
    }
}