﻿using System;
using System.Data;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;
using VirtualClassRoom;

/// <summary>
/// Summary description for ClsExaminationSchedule
/// </summary>
public class Cls_ExaminationSchedule
{

    private int examinationId;
    private string  examinationtext;
    private string examinationDate;
    private int courseId;
    private int lectureId;
    private int facultyId;
    private string  passPercentageDecided;
    private int noOfQuestions;

    // constructor
    public Cls_ExaminationSchedule()
    {
    }

    public static DataSet ShowCourseId(int id)
    {
        try
        {
            SqlParameter p = new SqlParameter("@facultyid", id);
            return SqlHelper.ExecuteDataset(Connection.con, CommandType.StoredProcedure, "Sp_ShowCourseidDetails", p);
        }
        catch (Exception ex)
        {

            throw new ArgumentException(ex.Message);
        }
    }

    public static DataSet ShowLectureId(int id)
    {
        try
        {
            SqlParameter p = new SqlParameter("@CourseId", id);
            return SqlHelper.ExecuteDataset(Connection.con, CommandType.StoredProcedure, "Sp_ShowLectureidDetailsSelectCourseid", p);
        }
        catch (Exception ex)
        {

            throw new ArgumentException(ex.Message);
        }
    }
    public int InsertExaminationSchedule()
    {
        try
        {
            SqlParameter []p=new SqlParameter[7];
            p[0]=new SqlParameter("@ExaminationText",Examinationtext);
            p[1]=new SqlParameter("@CourseId",CourseId);
            p[2]=new SqlParameter("@LectureId",LectureId);
            p[3]=new SqlParameter("@FacultyId",FacultyId);
            p[4]=new SqlParameter("@PassPercentageDecided",PassPercentageDecided);
            p[5]=new SqlParameter("@NoOfQuestions",NoOfQuestions);
            p[6]=new SqlParameter("@ExaminationId",SqlDbType.BigInt);
            p[6].Direction = ParameterDirection.Output;
            SqlHelper.ExecuteNonQuery(Connection.con, CommandType.StoredProcedure, "Sp_ExaminationSchedule_Insert", p);
            return Convert.ToInt32(p[6].Value);
        }
        catch (Exception ex)
        {

            throw new ArgumentException(ex.Message);
        }
    }



    public int ExaminationId { get { return examinationId; } set { examinationId = value; } }
    public string Examinationtext { get { return examinationtext; } set { examinationtext = value; } }
    public string ExaminationDate { get { return examinationDate; } set { examinationDate = value; } }
    public int CourseId { get { return courseId; } set { courseId = value; } }
    public int LectureId { get { return lectureId; } set { lectureId = value; } }
    public int FacultyId { get { return facultyId; } set { facultyId = value; } }
    public string  PassPercentageDecided { get { return passPercentageDecided; } set { passPercentageDecided = value; } }
    public int NoOfQuestions { get { return noOfQuestions; } set { noOfQuestions = value; } }
}
