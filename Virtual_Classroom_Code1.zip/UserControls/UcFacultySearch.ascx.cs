﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

public partial class UserControls_UcFacultySearch : System.Web.UI.UserControl
{
    protected void Page_Load(object sender, EventArgs e)
    {

        lblMsg.Text = "";
    }
    protected void btnSearch_Click(object sender, EventArgs e)
    {
        GetData();
    }
    protected void grdFaculty_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        try
        {
            grdFaculty.PageIndex = e.NewPageIndex;
            GetData();
        }
        catch (Exception ex)
        {

            lblMsg.Text = ex.Message;
        }
    }
    public void GetData()
    {
        try
        {
            DataSet ds = clsCourses.SearchFacultyData(txtfaculty.Text);

            if (ds.Tables[0].Rows.Count != 0)
            {
                grdFaculty.DataSource = ds.Tables[0];
                grdFaculty.DataBind();
            }
            else
            {
                grdFaculty.EmptyDataText = "No Match found with this Faculty name";
                grdFaculty.DataBind();
            }
        }
        catch (Exception ex)
        {
            lblMsg.Text = ex.Message;
        }
    
    }
}
