﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

public partial class UserControls_frmStudentSearch : System.Web.UI.UserControl
{
    protected void Page_Load(object sender, EventArgs e)
    {

        lblMsg.Text = "";
    }
    protected void btnSearch_Click(object sender, EventArgs e)
    {
        GetData();
    }
    protected void grdStudent_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        try
        {
            grdStudent.PageIndex = e.NewPageIndex;
            GetData();
        }
        catch (Exception ex)
        {

            lblMsg.Text = ex.Message;
        }
    }
    public void GetData()
    {
        try
        {
            DataSet ds = clsCourses.SearchStudentData(txtstudent.Text);

            if (ds.Tables[0].Rows.Count != 0)
            {
                grdStudent.DataSource = ds.Tables[0];
                grdStudent.DataBind();
            }
            else
            {
                grdStudent.EmptyDataText = "No Match found with this Student name";
                grdStudent.DataBind();
            }
        }
        catch (Exception ex)
        {
            lblMsg.Text = ex.Message;
        }
    }
}
