﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

public partial class UserControls_UcCourseSearch : System.Web.UI.UserControl
{
    protected void Page_Load(object sender, EventArgs e)
    {
        lblMsg.Text = "";
    }
    protected void btnSearch_Click(object sender, EventArgs e)
    {
        GetData();
    }
    protected void grdCourse_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        grdCourse.PageIndex = e.NewPageIndex;
        GetData();
    }
    public void GetData()
    {
        try
        {
            DataSet ds = clsCourses.GetSearchedCourse(txtCourse.Text);
            if (ds.Tables[0].Rows.Count != 0)
            {
                grdCourse.DataSource = ds.Tables[0];
                grdCourse.DataBind();
            }
            else
            {
                grdCourse.EmptyDataText = "No Match found with this course name";
                grdCourse.DataBind();
            }
        }
        catch (Exception ex)
        {
            lblMsg.Text = ex.Message;
        }
    }
}
