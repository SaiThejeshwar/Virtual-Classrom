﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;

public partial class frmAllCoursesVideoDemos : System.Web.UI.Page
{
    static int id;
    DataSet ds;
    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
           
            
        }
        catch (Exception ex)
        {

           
        }
    }

    protected void GridShowDetails_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        try
        {
            id = Convert.ToInt32(e.CommandArgument);

            if (e.CommandName == "video")
            {

                datalistvideo.DataSource = Cls_NewsLetterMaster.showLectureMasterDetailsDownloading(id);
                datalistvideo.DataBind();
            }
            else if (e.CommandName == "Audio")
            {
                datalistvideo.DataSource = Cls_NewsLetterMaster.showLectureMasterDetailsDownloading(id);
                datalistvideo.DataBind();
            }
            else if (e.CommandName == "Assignment")
            {
                ds = Cls_NewsLetterMaster.showLectureMasterDetailsDownloading(id);
                if (ds.Tables[0].Rows.Count != 0)
                {

                    byte[] FileContent = (byte[])ds.Tables[0].Rows[0][14];
                    string FileName = (string)ds.Tables[0].Rows[0][13];
                    string[] fileSplit = FileName.Split('.');
                    int Loc = fileSplit.Length;
                    string FileExtention = "." + fileSplit[Loc - 1].ToUpper();

                    int i = 0;
                    if (FileExtention == ".DOC" || FileExtention == ".DOCX")
                    {
                        Response.ContentType = "application/vnd.ms-word";
                        Response.AddHeader("content-disposition", "inline;filename=" + FileName);
                        i = 1;
                    }
                    if (i == 1)
                    {
                        Response.Charset = "";
                        Response.Cache.SetCacheability(HttpCacheability.NoCache);
                        Response.BinaryWrite(FileContent);
                        Response.End();
                    }
                    else
                        lblMsg.Text = "Problom in downloading the file..";

                }
            }
            else if (e.CommandName == "Document")
            {
                ds = Cls_NewsLetterMaster.showLectureMasterDetailsDownloading(id);
                if (ds.Tables[0].Rows.Count != 0)
                {

                    byte[] FileContent = (byte[])ds.Tables[0].Rows[0][12];
                    string FileName = (string)ds.Tables[0].Rows[0][11];
                    string[] fileSplit = FileName.Split('.');
                    int Loc = fileSplit.Length;
                    string FileExtention = "." + fileSplit[Loc - 1].ToUpper();

                    int i = 0;
                    if (FileExtention == ".DOC" || FileExtention == ".DOCX")
                    {
                        Response.ContentType = "application/vnd.ms-word";
                        Response.AddHeader("content-disposition", "inline;filename=" + FileName);
                        i = 1;
                    }
                    if (i == 1)
                    {
                        Response.Charset = "";
                        Response.Cache.SetCacheability(HttpCacheability.NoCache);
                        Response.BinaryWrite(FileContent);
                        Response.End();
                    }
                    else
                        lblMsg.Text = "Problom in downloading the file..";
                }

            }
            else if (e.CommandName == "PowerPoint")
            {
                ds = Cls_NewsLetterMaster.showLectureMasterDetailsDownloading(id);
                if (ds.Tables[0].Rows.Count != 0)
                {

                    byte[] FileContent = (byte[])ds.Tables[0].Rows[0][10];
                    string FileName = (string)ds.Tables[0].Rows[0][9];
                    string[] fileSplit = FileName.Split('.');
                    int Loc = fileSplit.Length;
                    string FileExtention = "." + fileSplit[Loc - 1].ToUpper();

                    int i = 0;

                    if (FileExtention == ".PPT")
                    {
                        Response.ContentType = "application/mspowerpoint";
                        Response.AddHeader("content-disposition", "inline;filename=" + FileName);
                        i = 1;
                    }
                    if (i == 1)
                    {
                        Response.Charset = "";
                        Response.Cache.SetCacheability(HttpCacheability.NoCache);
                        Response.BinaryWrite(FileContent);
                        Response.End();
                    }
                    else
                        lblMsg.Text = "Problom in downloading the file..";
                }
            }

        }


        catch (Exception ex)
        {

            lblMsg.Text = ex.Message;
        }
    }

}
